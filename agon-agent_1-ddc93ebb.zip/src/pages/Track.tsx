import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Package, MapPin, User, Loader2, Search } from 'lucide-react';
import { fmt } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';
const STEPS = ['paid', 'processing', 'shipped', 'ready_for_pickup', 'delivered', 'completed'];
const STEP_LABEL: Record<string, string> = { paid: 'Paid', pending: 'Received', processing: 'Processing', shipped: 'Shipped', ready_for_pickup: 'Ready for pickup', delivered: 'Delivered', completed: 'Completed', refunded: 'Refunded' };
export default function Track() {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  const [orders, setOrders] = useState<any[]>([]);
  const [busy, setBusy] = useState(true);
  const [lookup, setLookup] = useState('');
  const [found, setFound] = useState<any>(null);
  const [msg, setMsg] = useState('');
  useEffect(() => {
    if (loading) return;
    if (!user) { setBusy(false); return; }
    fetch(`/api/orders?email=${encodeURIComponent(user.email)}`).then(r => r.json()).then(d => { if (Array.isArray(d)) setOrders(d); }).catch(() => {}).finally(() => setBusy(false));
  }, [loading, user?.email]);
  const find = async (e: any) => {
    e.preventDefault(); setMsg(''); setFound(null);
    if (!lookup.trim()) return;
    const all = await fetch('/api/orders').then(r => r.json()).catch(() => []);
    const o = (Array.isArray(all) ? all : []).find((x: any) => x.order_number?.toLowerCase() === lookup.trim().toLowerCase());
    if (o) setFound(o); else setMsg('No order found with that number. Check your confirmation email.');
  };
  const Card = ({ o }: any) => {
    const idx = STEPS.indexOf(o.status);
    return (
      <div className="bg-white border rounded-2xl p-5">
        <div className="flex justify-between items-center flex-wrap gap-2">
          <p className="font-bold">{o.order_number} · {fmt(o.total)}</p>
          <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 uppercase">{STEP_LABEL[o.status] || o.status}</span>
        </div>
        <p className="text-xs text-stone-500 mt-1">{(o.items || []).map((i: any) => `${i.title} ×${i.qty}`).join(' · ')} — {o.created_at ? new Date(o.created_at).toLocaleDateString() : ''}</p>
        {o.status !== 'refunded' && (
          <div className="flex items-center gap-1 mt-3">
            {STEPS.map((s, i) => <div key={s} className="flex-1"><div className={`h-2 rounded-full ${idx >= 0 && i <= idx ? 'bg-amber-400' : 'bg-stone-200'}`} /><p className="text-[9px] text-stone-500 mt-1 text-center hidden sm:block">{STEP_LABEL[s]}</p></div>)}
          </div>
        )}
        <div className="text-xs text-stone-600 mt-3 space-y-1 bg-stone-50 rounded-xl p-3">
          {o.tracking_number ? <p className="flex items-center gap-1"><Package className="w-3.5 h-3.5" /><b>Tracking:</b> {o.tracking_number}</p> : <p className="flex items-center gap-1"><Package className="w-3.5 h-3.5" />Tracking added as soon as it ships.</p>}
          <p className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{o.shipping_address?.fulfillment === 'pickup' ? 'Free pickup in Naperville, Illinois — Sat–Sun, 10am–4pm. Details emailed after checkout.' : o.shipping_address?.fulfillment === 'delivery' ? 'Naperville-area local delivery — we confirm the exact fee and window before dispatch.' : `Shipping to ${o.shipping_address?.address || ''} ${o.shipping_address?.city || ''} ${o.shipping_address?.zip || ''}`}</p>
        </div>
      </div>
    );
  };
  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="font-display text-3xl font-black">Order Tracking</h1>
      <p className="text-sm text-stone-500 mt-1">Live status, shipping info, and tracking numbers.</p>
      <form onSubmit={find} className="flex gap-2 mt-4">
        <div className="relative flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" /><input value={lookup} onChange={e => setLookup(e.target.value)} placeholder="Enter order number (e.g. RT-ABC123)" className="w-full border rounded-xl pl-9 pr-3 py-2.5 text-sm bg-white" /></div>
        <button className="bg-black text-amber-300 text-sm font-bold px-5 rounded-xl">Track</button>
      </form>
      {msg && <p className="text-sm text-red-600 mt-2">{msg}</p>}
      {found && <div className="mt-3"><Card o={found} /></div>}
      <div className="mt-6 space-y-3">
        <h2 className="font-bold text-sm uppercase tracking-widest text-stone-400">{user ? 'Your orders' : 'Your orders'}</h2>
        {busy ? <div className="bg-white rounded-2xl h-32 animate-pulse" /> : !user ? (
          <div className="bg-white border rounded-2xl p-8 text-center"><User className="w-6 h-6 mx-auto text-stone-400" /><p className="font-bold mt-2 text-sm">Sign in to see all your orders</p><p className="text-xs text-stone-500">Or look up any order by number above — no account needed.</p><button onClick={() => nav('/login')} className="mt-3 text-sm font-bold bg-black text-amber-300 px-5 py-2.5 rounded-full">Sign In</button></div>
        ) : orders.length === 0 ? <p className="text-sm text-stone-500 bg-white border rounded-2xl p-6 text-center">No orders yet. <Link to="/shop" className="underline font-bold">Start hunting</Link>.</p>
        : orders.map(o => <Card key={o.id} o={o} />)}
      </div>
    </div>
  );
}
