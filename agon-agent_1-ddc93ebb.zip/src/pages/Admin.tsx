import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Package, Users, BarChart3, Ticket, Settings as SetIcon, Inbox, Loader2, Upload, X, Check } from 'lucide-react';
import { fmt, effPrice } from '../lib/utils';
import { uploadProductImage } from '../lib/upload';
const INP = 'w-full border border-stone-300 rounded-xl px-3 py-2.5 text-sm focus:border-amber-500 focus:outline-none min-h-[44px]';
export default function Admin() {
  const [tab, setTab] = useState('inventory');
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [coupons, setCoupons] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [settings, setSettings] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const load = async () => {
    setLoading(true);
    try {
      const [p, o, c, pr, cp, an, st] = await Promise.all([
        fetch('/api/products?limit=200').then(r => r.json()), fetch('/api/orders').then(r => r.json()),
        fetch('/api/categories').then(r => r.json()), fetch('/api/profiles').then(r => r.json()),
        fetch('/api/coupons').then(r => r.json()),
        fetch('/api/analytics').then(r => r.json()).catch(() => null), fetch('/api/settings').then(r => r.json()).catch(() => ({}))
      ]);
      if (Array.isArray(p)) setProducts(p); if (Array.isArray(o)) setOrders(o);
      if (Array.isArray(c)) setCats(c); if (Array.isArray(pr)) setProfiles(pr);
      if (Array.isArray(cp)) setCoupons(cp);
      if (an) setAnalytics(an); if (st) setSettings(st);
    } catch {} finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);
  const delProduct = async (id: number) => { if (!confirm('Delete this item?')) return; await fetch('/api/products', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); load(); };
  const markSold = async (p: any, sold: boolean) => {
    await fetch('/api/products', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: p.id, status: sold ? 'sold' : 'active', quantity: sold ? 0 : Math.max(1, p.quantity || 1) }) });
    load();
  };
  const saveSettings = async () => { await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(settings) }); alert('Settings saved — checkout uses these live.'); };
  const tabs: any[] = [['inventory', `Inventory (${products.length})`, Package], ['orders', `Orders (${orders.length})`, Inbox], ['customers', `Customers (${profiles.length})`, Users], ['analytics', 'Analytics', BarChart3], ['coupons', 'Coupons', Ticket], ['settings', 'Fees & Settings', SetIcon]];
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="font-display text-3xl font-black">ReTreasures Dashboard</h1>
      <p className="text-sm text-stone-500">Add items from your phone in under a minute · manage orders & customers</p>
      <div className="flex gap-2 mt-4 overflow-x-auto pb-1">{tabs.map(([k, l, Icon]: any) => <button key={k} onClick={() => setTab(k)} className={`flex items-center gap-1.5 px-4 py-2.5 rounded-full text-sm font-bold whitespace-nowrap border ${tab === k ? 'bg-black text-amber-300 border-black' : 'bg-white border-stone-200'}`}><Icon className="w-4 h-4" />{l}</button>)}</div>
      {loading ? <div className="bg-white rounded-2xl h-64 animate-pulse mt-4 flex items-center justify-center"><Loader2 className="animate-spin" /></div> : <>
        {tab === 'inventory' && (
          <div className="mt-4 bg-white border rounded-2xl p-4">
            <button onClick={() => { setEditing(null); setShowForm(!showForm); }} className="bg-black text-amber-300 text-sm font-bold px-5 py-3 rounded-xl flex items-center gap-1.5 min-h-[48px]"><Plus className="w-4 h-4" />{showForm ? 'Close Form' : '＋ Add Item'}</button>
            {(showForm || editing) && <ProductForm initial={editing} cats={cats} onDone={() => { setShowForm(false); setEditing(null); load(); }} />}
            <div className="overflow-x-auto mt-3"><table className="w-full text-sm min-w-[720px]"><thead><tr className="text-left text-xs text-stone-400 uppercase border-b"><th className="py-2">Item</th><th>Price</th><th>Qty</th><th>Status</th><th className="text-right">Actions</th></tr></thead><tbody>{products.map(p => (
              <tr key={p.id} className="border-b border-stone-100">
                <td className="py-2 font-semibold max-w-[240px]"><span className="truncate block">{p.title}</span><span className="text-[11px] font-mono text-stone-400">{p.sku || 'no SKU'}</span></td>
                <td className="font-bold whitespace-nowrap">{p.sale_price ? <><span className="text-red-700">{fmt(p.sale_price)}</span> <span className="line-through text-stone-400 font-normal text-xs">{fmt(p.price)}</span></> : fmt(effPrice(p))}</td>
                <td>{p.quantity}</td>
                <td className="text-xs"><span className={`px-2 py-0.5 rounded-full font-bold ${p.status === 'sold' ? 'bg-stone-800 text-white' : p.status === 'draft' ? 'bg-stone-200 text-stone-600' : 'bg-emerald-100 text-emerald-700'}`}>{p.status === 'sold' ? 'SOLD' : p.status.toUpperCase()}</span>{p.featured ? ' ★' : ''}</td>
                <td className="text-right whitespace-nowrap">
                  <button onClick={() => markSold(p, p.status !== 'sold')} title={p.status === 'sold' ? 'Relist' : 'Mark sold'} className="p-2 text-emerald-600"><Check className="w-4 h-4" /></button>
                  <button onClick={() => { setEditing(p); setShowForm(true); window.scrollTo(0, 0); }} className="p-2 text-sky-600"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => delProduct(p.id)} className="p-2 text-red-500"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>))}</tbody></table></div>
          </div>
        )}
        {tab === 'orders' && (
          <div className="mt-4 space-y-3">{orders.map(o => (
            <div key={o.id} className="bg-white border rounded-2xl p-4 text-sm">
              <div className="flex justify-between flex-wrap gap-2"><p className="font-bold">{o.order_number} · {o.customer_name} · {o.customer_email} · {fmt(o.total)}</p><StatusPill s={o.status} /></div>
              <p className="text-xs text-stone-500 mt-1">{(o.items || []).map((i: any) => `${i.title}×${i.qty}`).join(' · ')} — {o.created_at ? new Date(o.created_at).toLocaleString() : ''}</p>
              <div className="flex gap-2 mt-2 flex-wrap items-center">
                <select value={o.status} onChange={async (e) => { await fetch('/api/orders', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: o.id, status: e.target.value }) }); load(); }} className="border rounded-lg px-2 py-2 text-xs font-bold">
                  {['pending', 'paid', 'processing', 'shipped', 'ready_for_pickup', 'delivered', 'completed', 'refunded'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <input placeholder="Tracking #" defaultValue={o.tracking_number || ''} id={`trk-${o.id}`} className="border rounded-lg px-2 py-2 text-xs w-44 min-h-[40px]" />
                <button onClick={async () => { const t = (document.getElementById(`trk-${o.id}`) as any)?.value; await fetch('/api/orders', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: o.id, status: 'shipped', tracking_number: t }) }); load(); }} className="text-xs font-bold border px-3 py-2 rounded-full min-h-[40px]">Save tracking + ship</button>
                <button onClick={async () => { await fetch('/api/orders', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: o.id, status: 'ready_for_pickup' }) }); load(); }} className="text-xs font-bold border px-3 py-2 rounded-full min-h-[40px]">Ready for pickup</button>
                <button onClick={async () => { if (!confirm('Refund this order?')) return; await fetch('/api/orders', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: o.id, payment_status: 'refunded', status: 'refunded' }) }); load(); }} className="text-xs font-bold border border-red-300 text-red-600 px-3 py-2 rounded-full min-h-[40px]">Refund</button>
              </div>
            </div>))}{orders.length === 0 && <p className="text-sm text-stone-500 bg-white border rounded-2xl p-8 text-center">No orders yet.</p>}</div>
        )}
        {tab === 'customers' && (
          <div className="mt-4 bg-white border rounded-2xl p-4 overflow-x-auto"><table className="w-full text-sm min-w-[600px]"><thead><tr className="text-left text-xs text-stone-400 uppercase border-b"><th className="py-2">Customer</th><th>Email</th><th>Phone</th><th>Orders</th><th>Total spent</th></tr></thead><tbody>{profiles.map(c => { const co = orders.filter(o => o.customer_email === c.email); return <tr key={c.id} className="border-b border-stone-100"><td className="py-2 font-semibold">{c.name || '—'}</td><td>{c.email}</td><td>{c.phone || '—'}</td><td>{co.length}</td><td className="font-bold">{fmt(co.reduce((s, o) => s + parseFloat(o.total || 0), 0))}</td></tr>; })}</tbody></table>{profiles.length === 0 && <p className="text-sm text-stone-400 text-center py-6">No customers yet — they appear after signup or first order.</p>}</div>
        )}
        {tab === 'analytics' && (
          analytics ? <div className="mt-4 space-y-4">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{[['Revenue', fmt(analytics.revenue)], ['Orders', analytics.orders], ['Items sold', analytics.itemsSold], ['Customers', analytics.customers], ['Items in stock', analytics.inventory], ['Low stock', analytics.lowStock], ['Avg order', fmt(analytics.avgOrder)], ['Products', analytics.inventory]].map(([l, v]) => <div key={l as string} className="bg-white border rounded-2xl p-4"><p className="text-[11px] uppercase tracking-widest text-stone-400">{l}</p><p className="text-2xl font-black">{v}</p></div>)}</div>
            <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold text-sm mb-3">Revenue — last 14 days</h3><div className="flex items-end gap-1 h-32">{analytics.last14.map((d: any) => { const mx = Math.max(...analytics.last14.map((x: any) => x.total), 1); return <div key={d.day} className="flex-1 flex flex-col items-center gap-1"><div className="w-full bg-gradient-to-t from-amber-500 to-amber-300 rounded-t" style={{ height: `${Math.max(4, d.total / mx * 110)}px` }} title={`${d.day}: ${fmt(d.total)}`} /><span className="text-[9px] text-stone-400">{d.day.slice(5)}</span></div>; })}</div></div>
            <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold text-sm mb-2">Top-selling categories</h3>{analytics.topCategories.length === 0 ? <p className="text-sm text-stone-400">Sales will appear here once orders come in.</p> : analytics.topCategories.map((c: any) => { const mx = Math.max(...analytics.topCategories.map((x: any) => x.total), 1); return <div key={c.name} className="flex items-center gap-3 py-1.5 text-sm"><span className="w-40 truncate font-semibold">{c.name}</span><div className="flex-1 bg-stone-100 rounded-full h-2.5"><div className="bg-amber-500 h-2.5 rounded-full" style={{ width: `${Math.min(100, c.total / mx * 100)}%` }} /></div><span className="font-bold">{fmt(c.total)}</span></div>; })}</div>
          </div> : <p className="text-sm text-stone-500 mt-4">Analytics unavailable.</p>
        )}
        {tab === 'coupons' && (
          <div className="mt-4 bg-white border rounded-2xl p-4">
            <CouponForm onDone={load} />
            <div className="space-y-2 mt-3">{coupons.map(c => <div key={c.id} className="flex items-center gap-3 border rounded-xl px-3 py-2 text-sm"><b className="font-mono">{c.code}</b><span>{c.discount_type === 'percent' ? c.discount_value + '% off' : fmt(c.discount_value) + ' off'}</span><span className="text-xs text-stone-400">min {fmt(c.min_order)}</span><span className={`text-xs font-bold ml-auto ${c.active ? 'text-emerald-600' : 'text-stone-400'}`}>{c.active ? 'ACTIVE' : 'OFF'}</span><button onClick={async () => { await fetch('/api/coupons', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: c.id }) }); load(); }} className="text-red-500"><Trash2 className="w-4 h-4" /></button></div>)}</div>
          </div>
        )}
        {tab === 'settings' && (
          <div className="mt-4 bg-white border rounded-2xl p-5 max-w-2xl space-y-3 text-sm">
            <p className="text-xs text-stone-500 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">Tax + shipping are configured here and shown at checkout. Connect <b>Stripe</b> (publishable key) and paste your <b>GA4</b> ID in index.html.</p>
            {[['tax_rate', 'Sales tax rate (e.g. 0.07 = 7%)'], ['shipping_flat', 'Flat shipping $'], ['free_shipping_over', 'Free shipping over $'], ['stripe_publishable_key', 'Stripe publishable key (pk_live_...)'], ['pickup_address', 'Pickup address / hours'], ['announcement', 'Announcement bar text']].map(([k, l]) => <label key={k} className="block font-bold">{l}<input value={settings[k] ?? ''} onChange={e => setSettings({ ...settings, [k]: e.target.value })} className={INP + ' mt-1 font-normal'} /></label>)}
            <button onClick={saveSettings} className="bg-black text-amber-300 font-bold px-6 py-3 rounded-xl min-h-[48px]">Save Settings</button>
          </div>
        )}
      </>}
    </div>
  );
}
function StatusPill({ s }: any) {
  const c: Record<string, string> = { paid: 'bg-sky-100 text-sky-800', shipped: 'bg-violet-100 text-violet-800', delivered: 'bg-emerald-100 text-emerald-800', completed: 'bg-emerald-100 text-emerald-800', refunded: 'bg-red-100 text-red-700', ready_for_pickup: 'bg-amber-100 text-amber-800' };
  return <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full uppercase ${c[s] || 'bg-stone-100 text-stone-600'}`}>{s}</span>;
}
function ProductForm({ initial, cats, onDone }: any) {
  const [f, setF] = useState<any>(initial ? { ...initial, images: (initial.images || []).join('\n') } : { title: '', description: '', brand: '', model: '', sku: '', category_id: '', condition: 'Good', price: '', sale_price: '', quantity: 1, images: '', dimensions: '', shipping_available: true, pickup_available: true, shipping_info: '', pickup_info: '', status: 'active', featured: false });
  const [busy, setBusy] = useState(false);
  const [upMsg, setUpMsg] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const set = (k: string, v: any) => setF((p: any) => ({ ...p, [k]: v }));
  const imgList: string[] = typeof f.images === 'string' ? f.images.split('\n').map((s: string) => s.trim()).filter(Boolean) : (f.images || []);
  const addFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files).filter(fl => fl.type.startsWith('image/')).slice(0, 8);
    if (!arr.length) return;
    setUpMsg('Uploading photos...');
    try {
      const urls: string[] = [];
      for (const fl of arr) urls.push(await uploadProductImage(fl));
      const cur = typeof f.images === 'string' ? f.images : (f.images || []).join('\n');
      set('images', [cur, ...urls].filter(Boolean).join('\n'));
      setUpMsg(`${urls.length} photo(s) uploaded!`);
    } catch (e: any) { setUpMsg('Upload failed: ' + e.message + ' — paste an image URL instead.'); }
    setTimeout(() => setUpMsg(''), 4000);
  };
  const save = async (e: any) => {
    e.preventDefault(); setBusy(true);
    try {
      const body: any = {
        title: f.title, description: f.description, brand: f.brand || null, model: f.model || null, sku: f.sku || null,
        category_id: f.category_id || null, condition: f.condition, price: f.price === '' ? null : parseFloat(f.price),
        sale_price: f.sale_price === '' || f.sale_price == null ? null : parseFloat(f.sale_price),
        quantity: parseInt(f.quantity) || 0, images: imgList, dimensions: f.dimensions || null,
        shipping_available: !!f.shipping_available, pickup_available: !!f.pickup_available,
        shipping_info: f.shipping_info || null, pickup_info: f.pickup_info || null,
        status: f.status, featured: !!f.featured,
        return_info: '14-day returns on every purchase. Unused with tags; buyer pays return shipping.'
      };
      const method = initial ? 'PUT' : 'POST';
      if (initial) body.id = initial.id;
      const res = await fetch('/api/products', { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (res.ok) onDone(); else alert('Save failed: ' + ((await res.json()).error || 'unknown error'));
    } finally { setBusy(false); }
  };
  return (
    <form onSubmit={save} className="bg-stone-50 border-2 border-amber-300 rounded-2xl p-4 mt-3 space-y-3">
      <h3 className="font-display font-bold text-lg">{initial ? 'Edit Item' : '＋ Add Item (10 quick steps)'}</h3>
      <div onDragOver={e => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onDrop={e => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files); }} className={`border-2 border-dashed rounded-2xl p-5 text-center bg-white ${dragOver ? 'border-amber-500 bg-amber-50' : 'border-stone-300'}`}>
        <Upload className="w-6 h-6 mx-auto text-amber-600" />
        <p className="text-sm font-bold mt-1">1 · Upload product photos</p>
        <p className="text-xs text-stone-500">Tap to choose or drag & drop (phone-friendly)</p>
        <label className="inline-block mt-2 bg-black text-amber-300 text-sm font-bold px-5 py-2.5 rounded-xl cursor-pointer">Choose Photos<input type="file" accept="image/*" multiple className="hidden" onChange={e => { if (e.target.files?.length) addFiles(e.target.files); e.target.value = ''; }} /></label>
        {upMsg && <p className="text-xs font-bold text-amber-700 mt-2">{upMsg}</p>}
        {imgList.length > 0 && <div className="flex gap-2 mt-3 overflow-x-auto justify-center">{imgList.map((u, i) => <div key={i} className="relative shrink-0"><img src={u} alt="" className="w-16 h-16 rounded-xl object-cover border" /><button type="button" onClick={() => set('images', imgList.filter((_, j) => j !== i).join('\n'))} className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center"><X className="w-3 h-3" /></button></div>)}</div>}
      </div>
      <label className="block font-bold text-sm">2 · Item name*<input value={f.title} onChange={e => set('title', e.target.value)} required placeholder="e.g. Vintage Pyrex Bowl Set" className={INP} /></label>
      <label className="block font-bold text-sm">3 · Description*<textarea value={f.description} onChange={e => set('description', e.target.value)} required placeholder="Condition details, flaws, story..." rows={3} className={INP} /></label>
      <label className="block font-bold text-sm">4 · Category<select value={f.category_id} onChange={e => set('category_id', e.target.value)} className={INP}><option value="">Choose category...</option>{cats.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label className="block font-bold text-sm">5 · Condition<select value={f.condition} onChange={e => set('condition', e.target.value)} className={INP}>{['New (Sealed)', 'Like New', 'Excellent', 'Good', 'Fair'].map(c => <option key={c}>{c}</option>)}</select></label>
      <div className="grid grid-cols-2 gap-2">
        <label className="block font-bold text-sm">6 · Price $*<input value={f.price} onChange={e => set('price', e.target.value)} type="number" step="0.01" required placeholder="49.99" className={INP} /></label>
        <label className="block font-bold text-sm">Sale price $ (optional)<input value={f.sale_price || ''} onChange={e => set('sale_price', e.target.value)} type="number" step="0.01" placeholder="39.99" className={INP} /></label>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <label className="block font-bold text-sm">7 · Quantity<input value={f.quantity} onChange={e => set('quantity', e.target.value)} type="number" min={0} className={INP} /></label>
        <label className="block font-bold text-sm">8 · SKU<input value={f.sku || ''} onChange={e => set('sku', e.target.value)} placeholder="RT-0001" className={INP} /></label>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <input value={f.brand || ''} onChange={e => set('brand', e.target.value)} placeholder="Brand (optional)" className={INP} />
        <input value={f.model || ''} onChange={e => set('model', e.target.value)} placeholder="Model # (optional)" className={INP} />
      </div>
      <input value={f.dimensions || ''} onChange={e => set('dimensions', e.target.value)} placeholder="Dimensions (optional)" className={INP} />
      <div className="bg-white border rounded-xl p-3 space-y-2">
        <p className="font-bold text-sm">9 · Shipping / pickup</p>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!f.shipping_available} onChange={e => set('shipping_available', e.target.checked)} className="w-4 h-4" /> Offers shipping</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!f.pickup_available} onChange={e => set('pickup_available', e.target.checked)} className="w-4 h-4" /> Offers local pickup</label>
        <input value={f.shipping_info || ''} onChange={e => set('shipping_info', e.target.value)} placeholder="Shipping note (optional)" className={INP} />
        <input value={f.pickup_info || ''} onChange={e => set('pickup_info', e.target.value)} placeholder="Pickup note (optional)" className={INP} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <label className="block font-bold text-sm">Status<select value={f.status} onChange={e => set('status', e.target.value)} className={INP}><option value="active">Published</option><option value="draft">Draft</option><option value="sold">Sold</option></select></label>
        <label className="flex items-center gap-2 text-sm pt-6"><input type="checkbox" checked={!!f.featured} onChange={e => set('featured', e.target.checked)} className="w-4 h-4" /> Featured on home</label>
      </div>
      <textarea value={typeof f.images === 'string' ? f.images : (f.images || []).join('\n')} onChange={e => set('images', e.target.value)} placeholder="Or paste image URLs — one per line" rows={2} className={INP} />
      <button disabled={busy} className="w-full bg-black text-amber-300 font-extrabold px-6 py-3.5 rounded-xl min-h-[52px]">10 · {busy ? 'Publishing...' : initial ? 'Save Changes' : 'Publish Item'}</button>
    </form>
  );
}
function CouponForm({ onDone }: any) {
  const [f, setF] = useState({ code: '', discount_type: 'percent', discount_value: 10, min_order: 0 });
  const save = async (e: any) => { e.preventDefault(); const r = await fetch('/api/coupons', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); if (r.ok) { setF({ code: '', discount_type: 'percent', discount_value: 10, min_order: 0 }); onDone(); } };
  return <form onSubmit={save} className="flex flex-wrap gap-2 text-sm"><input value={f.code} onChange={e => setF({ ...f, code: e.target.value })} required placeholder="CODE" className={INP + ' w-32 uppercase'} /><select value={f.discount_type} onChange={e => setF({ ...f, discount_type: e.target.value })} className={INP + ' w-32'}><option value="percent">% off</option><option value="fixed">$ off</option></select><input value={f.discount_value} onChange={e => setF({ ...f, discount_value: parseFloat(e.target.value) })} type="number" className={INP + ' w-24'} /><input value={f.min_order} onChange={e => setF({ ...f, min_order: parseFloat(e.target.value) })} type="number" placeholder="Min $" className={INP + ' w-24'} /><button className="bg-black text-amber-300 font-bold px-4 py-2 rounded-xl">Add</button></form>;
}
