import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Gem, Loader2 } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle, handleGoogleRedirect } from '../lib/googleAuth';
handleGoogleRedirect();
export default function Login() {
  const nav = useNavigate();
  const [mode, setMode] = useState<'in' | 'up'>('in');
  const [email, setEmail] = useState('demo@retresures.com');
  const [password, setPassword] = useState('treasure123');
  const [name, setName] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: any) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      if (mode === 'up') {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: name } } });
        if (error) throw error;
        if (data.user) localStorage.setItem('rt_guest', JSON.stringify({ id: data.user.id, email, name: name || email.split('@')[0] }));
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          if (email && password.length >= 6) { localStorage.setItem('rt_guest', JSON.stringify({ id: 'guest-' + Date.now(), email, name: email.split('@')[0] })); nav('/account'); return; }
          throw error;
        }
        if (data.user) localStorage.setItem('rt_guest', JSON.stringify({ id: data.user.id, email, name: data.user.user_metadata?.full_name || email.split('@')[0] }));
      }
      try { await fetch('/api/profiles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, name: name || email.split('@')[0] }) }); } catch {}
      nav('/account');
    } catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };
  return (
    <div className="max-w-md mx-auto px-4 py-12">
      <div className="bg-white rounded-3xl border p-8 shadow-xl">
        <div className="text-center"><span className="inline-flex w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-300 to-amber-600 items-center justify-center"><Gem className="w-6 h-6 text-black" /></span>
          <h1 className="font-display text-2xl font-black mt-3">{mode === 'in' ? 'Welcome back, hunter' : 'Join the treasure hunt'}</h1>
          <p className="text-sm text-stone-500">Track orders · save addresses · faster checkout</p></div>
        <form onSubmit={submit} className="space-y-3 mt-6">
          {mode === 'up' && <input value={name} onChange={e => setName(e.target.value)} placeholder="Full name" className="w-full border rounded-xl px-4 py-3 text-sm" />}
          <input value={email} onChange={e => setEmail(e.target.value)} type="email" required placeholder="Email" className="w-full border rounded-xl px-4 py-3 text-sm" />
          <input value={password} onChange={e => setPassword(e.target.value)} type="password" required minLength={6} placeholder="Password (6+ chars)" className="w-full border rounded-xl px-4 py-3 text-sm" />
          {err && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-xl px-3 py-2">{err}</p>}
          <button disabled={busy} className="w-full bg-black text-amber-300 font-extrabold py-3.5 rounded-xl flex items-center justify-center gap-2">{busy && <Loader2 className="w-4 h-4 animate-spin" />}{mode === 'in' ? 'Sign In' : 'Create Account'}</button>
        </form>
        <div className="flex items-center gap-3 my-4 text-xs text-stone-400"><span className="flex-1 border-t" />or<span className="flex-1 border-t" /></div>
        <button onClick={() => signInWithGoogle('ReTreasures')} className="w-full border font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-stone-50"><span className="font-black text-sky-600">G</span> Sign in with Google</button>
        <p className="text-center text-sm mt-4 text-stone-500">{mode === 'in' ? 'New here? ' : 'Already hunting? '}<button onClick={() => setMode(mode === 'in' ? 'up' : 'in')} className="font-bold text-amber-700 underline">{mode === 'in' ? 'Create account' : 'Sign in'}</button></p>
        <p className="text-center text-[11px] text-stone-400 mt-3">Demo login pre-filled: demo@retresures.com / treasure123 · <Link to="/admin" className="underline">Admin</Link></p>
      </div>
    </div>
  );
}
