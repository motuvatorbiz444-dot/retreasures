import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Refrigerator, Car, Shirt, Gem, Tv, Sofa } from 'lucide-react';

const ICONS: Record<string, any> = {
  Appliances: Refrigerator,
  Automotive: Car,
  'Clothing & Fashion': Shirt,
  Collectibles: Gem,
  Electronics: Tv,
  Furniture: Sofa,
};

export default function Categories() {
  const [cats, setCats] = useState<any[]>([]);
  const [counts, setCounts] = useState<Record<number, number>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/categories').then((r) => r.json()).catch(() => []),
      fetch('/api/products?status=active&limit=200')
        .then((r) => r.json())
        .catch(() => []),
    ])
      .then(([c, p]) => {
        if (Array.isArray(c)) setCats(c);
        if (Array.isArray(p)) {
          const m: Record<number, number> = {};
          p.forEach((x: any) => {
            if (x.category_id) m[x.category_id] = (m[x.category_id] || 0) + 1;
          });
          setCounts(m);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const wanted = [
    'Appliances',
    'Automotive',
    'Clothing & Fashion',
    'Collectibles',
    'Electronics',
    'Furniture',
  ];
  const list = wanted
    .map((n) => cats.find((c: any) => c.name === n) || { name: n })
    .filter(Boolean);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="font-display text-3xl sm:text-4xl font-black">Categories</h1>
      <p className="text-sm text-stone-500 mt-1">
        Six shelves of treasure — pick your hunt.
      </p>
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="h-36 rounded-2xl animate-pulse bg-white border"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4 mt-6">
          {list.map((c: any) => {
            const Icon = ICONS[c.name] || Gem;
            return (
              <Link
                key={c.name}
                to={`/shop?category=${encodeURIComponent(c.name)}`}
                className="min-h-[44px] bg-[#111] rounded-2xl p-6 border border-amber-500/15 hover:border-amber-400 hover:-translate-y-1 transition-all group text-center"
              >
                <Icon
                  className="w-8 h-8 mx-auto text-amber-300"
                  strokeWidth={1.5}
                />
                <div className="font-bold text-stone-100 group-hover:text-amber-300 text-sm mt-2">
                  {c.name} ({c.id ? counts[c.id] || 0 : 0})
                </div>
                {c.description && (
                  <div className="text-[11px] text-stone-500 mt-1 line-clamp-2">
                    {c.description}
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
