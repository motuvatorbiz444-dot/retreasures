import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Sparkles, ArrowRight, Truck } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { CAT_TILES } from '../lib/catMeta';
import { SHIP_LINE, PICKUP_COPY, DELIVERY_DETAILS, SHIPPING_COPY } from '../lib/siteCopy';

export default function Home() {
  const [products, setProducts] = useState<any[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [sold, setSold] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  const [gridCat, setGridCat] = useState('');
  const [gridCond, setGridCond] = useState('');
  const [gridPrice, setGridPrice] = useState('');
  const [gridSort, setGridSort] = useState('new');

  useEffect(() => {
    Promise.all([
      fetch('/api/products?status=active&limit=100').then((r) => r.json()),
      fetch('/api/categories').then((r) => r.json()),
      fetch('/api/products?status=sold&limit=12').then((r) => r.json()).catch(() => []),
    ])
      .then(([p, c, s]) => {
        setProducts(Array.isArray(p) ? p : []);
        setCats(Array.isArray(c) ? c : []);
        setSold(Array.isArray(s) ? s : []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const avail = products.filter((p) => p.status === 'active' && (p.quantity || 0) > 0);
  const countByCat = (name: string) => {
    const c = cats.find((x: any) => x.name === name);
    if (!c) return 0;
    return avail.filter((p) => p.category_id === c.id).length;
  };
  const justListed = [...avail]
    .sort(
      (a, b) =>
        new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()
    )
    .slice(0, 4);

  const effPrice = (p: any) => {
    const sale = parseFloat(p?.sale_price);
    const reg = parseFloat(p?.price);
    if (!isNaN(sale) && sale > 0 && !isNaN(reg) && sale < reg) return sale;
    return isNaN(reg) ? 0 : reg;
  };

  const gridItems = (() => {
    let list = [...avail];
    if (gridCat) {
      const c = cats.find((x: any) => x.name === gridCat);
      list = c ? list.filter((p) => p.category_id === c.id) : [];
    }
    if (gridCond) list = list.filter((p) => p.condition === gridCond);
    if (gridPrice === 'under25') list = list.filter((p) => effPrice(p) < 25);
    if (gridPrice === '25-50')
      list = list.filter((p) => effPrice(p) >= 25 && effPrice(p) <= 50);
    if (gridPrice === '50-150')
      list = list.filter((p) => effPrice(p) > 50 && effPrice(p) <= 150);
    if (gridPrice === '150plus') list = list.filter((p) => effPrice(p) > 150);
    if (gridSort === 'low')
      list = [...list].sort((a, b) => effPrice(a) - effPrice(b));
    else if (gridSort === 'high')
      list = [...list].sort((a, b) => effPrice(b) - effPrice(a));
    else
      list = [...list].sort(
        (a, b) =>
          new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()
      );
    return list;
  })();

  const subscribe = async (e: any) => {
    e.preventDefault();
    setMsg('');
    const res = await fetch('/api/newsletter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    if (res.ok) {
      setMsg('You are on the list! New treasures land in your inbox.');
      setEmail('');
    } else {
      const d = await res.json().catch(() => ({}));
      setMsg(d.error || 'Something went wrong.');
    }
  };

  const sel =
    'w-full min-h-[44px] border border-stone-300 rounded-xl px-3 py-2.5 text-sm bg-white focus:border-amber-500 focus:outline-none';

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-[#111]">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            background:
              'radial-gradient(800px 400px at 20% 20%, rgba(217,180,80,0.35), transparent), radial-gradient(700px 380px at 85% 70%, rgba(217,180,80,0.22), transparent)',
          }}
        />
        <img
          src="https://images.unsplash.com/photo-1519643381401-22c77e60520e?w=1600&q=60&auto=format&fit=crop"
          alt="Treasure"
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="relative max-w-7xl mx-auto px-4 py-16 sm:py-24 text-center">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}>
            <span className="inline-flex items-center gap-1.5 bg-amber-400/10 border border-amber-400/40 text-amber-300 text-xs font-bold tracking-[0.2em] uppercase px-4 py-1.5 rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              Hidden Gems · Second Chances · Real Treasures
            </span>
            <p className="text-xs font-bold tracking-[0.2em] uppercase text-amber-300 mt-5">
              Resale in Naperville, Illinois · shipping nationwide
            </p>
            <h1
              className="font-display text-4xl sm:text-6xl font-black mt-3 leading-tight"
              style={{ color: '#faf6ec' }}
            >
              DISCOVER YOUR
              <br />
              <span className="bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 bg-clip-text text-transparent">
                NEXT TREASURE
              </span>
            </h1>
            <p className="text-stone-300 mt-4 max-w-xl mx-auto">
              Secondhand electronics, furniture, tools, and collectibles — each one
              inspected, honestly graded, and priced to move. Flat-rate shipping, or
              free local pickup in Naperville, Illinois.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
              <Link
                to="/shop"
                className="min-h-[44px] bg-gradient-to-r from-amber-300 to-amber-500 text-black font-extrabold px-8 py-3.5 rounded-full flex items-center justify-center gap-2 hover:brightness-110"
              >
                <ShoppingBag className="w-5 h-5" />
                SHOP NOW
              </Link>
              <Link
                to="/shipping"
                className="min-h-[44px] border border-amber-400/60 text-amber-200 font-extrabold px-8 py-3.5 rounded-full flex items-center justify-center gap-2 hover:bg-white/10"
              >
                <Truck className="w-5 h-5" />
                LOCAL DELIVERY INFORMATION
              </Link>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 justify-center mt-3">
              <Link
                to="/shop?sort=new"
                className="text-sm font-bold text-stone-300 hover:text-amber-300 underline underline-offset-4 px-4 py-2 min-h-[44px] inline-flex items-center justify-center"
              >
                Browse new arrivals →
              </Link>
            </div>
            <div className="flex flex-wrap justify-center gap-x-8 gap-y-4 mt-10 text-center">
              {[
                '17+ ITEMS IN STOCK',
                '6 CATEGORIES',
                'DEALS FROM $5',
                '40+ ITEMS REHOMED',
              ].map((stat) => (
                <div
                  key={stat}
                  className="font-display text-lg sm:text-xl font-bold text-amber-300 tracking-wide"
                >
                  {stat}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* SHOP BY CATEGORY — exactly 6 tiles, no emoji */}
      <section className="max-w-7xl mx-auto px-4 mt-14">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-1">
          Shop by Category
        </h2>
        <p className="text-sm text-stone-500 mb-5">
          Six shelves of treasure — pick your hunt.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {CAT_TILES.map(({ name, Icon }) => (
            <Link
              key={name}
              to={`/shop?category=${encodeURIComponent(name)}`}
              className="min-h-[44px] bg-[#111] text-center rounded-2xl p-4 border border-amber-500/15 hover:border-amber-400 hover:-translate-y-1 transition-all group"
            >
              <Icon className="w-7 h-7 mx-auto text-amber-300" strokeWidth={1.5} />
              <div className="text-xs font-bold text-stone-200 group-hover:text-amber-300 leading-tight mt-2">
                {name} ({countByCat(name)})
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* JUST LISTED THIS WEEK */}
      {loading ? (
        <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white rounded-2xl h-64 animate-pulse" />
          ))}
        </div>
      ) : (
        justListed.length > 0 && (
          <section className="max-w-7xl mx-auto px-4 mt-12">
            <div className="flex items-end justify-between mb-4">
              <div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold">
                  Just Listed This Week
                </h2>
                <p className="text-sm text-stone-500">
                  The freshest finds on the shelf — max 4, then they&apos;re gone.
                </p>
              </div>
              <Link
                to="/shop?sort=new"
                className="min-h-[44px] inline-flex items-center text-sm font-bold text-amber-700 hover:text-amber-800 gap-1 shrink-0 px-2"
              >
                What&apos;s new
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
              {justListed.map((p: any) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
          </section>
        )
      )}

      {/* SHOP ALL TREASURES — one filterable grid */}
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-1">
          Shop All Treasures
        </h2>
        <p className="text-sm text-stone-500 mb-4">
          Filter by category, condition, and price.
        </p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 bg-white border rounded-2xl p-3 sm:p-4">
          <label className="block text-xs font-bold">
            Category
            <select
              value={gridCat}
              onChange={(e) => setGridCat(e.target.value)}
              className={`${sel} mt-1`}
            >
              <option value="">All categories</option>
              {CAT_TILES.map(({ name }) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs font-bold">
            Condition
            <select
              value={gridCond}
              onChange={(e) => setGridCond(e.target.value)}
              className={`${sel} mt-1`}
            >
              <option value="">Any condition</option>
              {['New (Sealed)', 'Like New', 'Excellent', 'Good', 'Fair'].map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs font-bold">
            Price
            <select
              value={gridPrice}
              onChange={(e) => setGridPrice(e.target.value)}
              className={`${sel} mt-1`}
            >
              <option value="">Any price</option>
              <option value="under25">Under $25</option>
              <option value="25-50">$25–$50</option>
              <option value="50-150">$50–$150</option>
              <option value="150plus">$150+</option>
            </select>
          </label>
          <label className="block text-xs font-bold">
            Sort
            <select
              value={gridSort}
              onChange={(e) => setGridSort(e.target.value)}
              className={`${sel} mt-1`}
            >
              <option value="new">Newest</option>
              <option value="low">Price low-high</option>
              <option value="high">Price high-low</option>
            </select>
          </label>
        </div>
        {(gridCat || gridCond || gridPrice) && (
          <button
            onClick={() => {
              setGridCat('');
              setGridCond('');
              setGridPrice('');
              setGridSort('new');
            }}
            className="min-h-[44px] text-xs underline text-stone-500 mt-2 px-2"
          >
            Clear filters
          </button>
        )}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5 mt-4">
          {gridItems.map((p: any) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
        {gridItems.length === 0 && !loading && (
          <p className="text-sm text-stone-500 bg-white border rounded-2xl p-6 text-center mt-4">
            No treasures match those filters — try widening the price range.
          </p>
        )}
      </section>

      {/* WHY RETREASURES — one row of three cards + testimonial placeholder */}
      <section className="max-w-7xl mx-auto px-4 mt-14">
        <div className="bg-[#111] rounded-3xl p-8 sm:p-12 border border-amber-500/20">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold text-center"
            style={{ color: '#faf6ec' }}
          >
            Why ReTreasures
          </h2>
          <div className="grid sm:grid-cols-3 gap-4 sm:gap-6 mt-8">
            {[
              [
                '1',
                'Inspected & honestly graded',
                'Every item is checked, photographed, and graded on our five-tier scale before it lists.',
              ],
              [
                '2',
                'Easy to buy',
                'Add to cart in seconds. Secure checkout with cards, Apple Pay, and Google Pay.',
              ],
              [
                '3',
                'Shipped or pickup',
                SHIP_LINE + ' 14-day returns on every purchase.',
              ],
            ].map(([n, t, d]) => (
              <div
                key={n}
                className="bg-white/5 border border-white/10 rounded-2xl p-6 text-center"
              >
                <div className="w-10 h-10 mx-auto rounded-full bg-gradient-to-br from-amber-300 to-amber-600 text-black font-black flex items-center justify-center">
                  {n}
                </div>
                <h3 className="font-bold text-lg mt-3" style={{ color: '#faf6ec' }}>
                  {t}
                </h3>
                <p className="text-sm text-stone-400 mt-1.5">{d}</p>
              </div>
            ))}
          </div>
          <div className="max-w-xl mx-auto mt-6 bg-white/5 border border-amber-400/30 rounded-2xl p-6 text-center">
            <p className="text-amber-200 font-display text-lg">[TESTIMONIAL HERE]</p>
          </div>
        </div>
      </section>

      {/* CONDITION GRADES */}
      <section id="condition-grades" className="max-w-7xl mx-auto px-4 mt-14 scroll-mt-24">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-1">
          Condition Grades
        </h2>
        <p className="text-sm text-stone-500 mb-4">
          Exactly what each badge means — no surprises.
        </p>
        <div className="bg-white border rounded-3xl p-6 sm:p-8 space-y-3 text-sm sm:text-[15px] text-stone-700 leading-relaxed">
          <p>
            <b>New (Sealed)</b> — unused, in original packaging.
          </p>
          <p>
            <b>Like New</b> — used once or twice, no visible wear.
          </p>
          <p>
            <b>Excellent</b> — light use, minor cosmetic marks, fully functional.
          </p>
          <p>
            <b>Good</b> — normal wear, works perfectly, flaws photographed.
          </p>
          <p>
            <b>Fair</b> — heavy cosmetic wear, works as described, priced
            accordingly.
          </p>
          <p className="font-bold text-stone-900">
            Every flaw is photographed before listing.
          </p>
        </div>
      </section>

      {/* SHIPPING & DELIVERY */}
      <section id="shipping-delivery" className="max-w-7xl mx-auto px-4 mt-14 scroll-mt-24">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-1">
          Shipping & Delivery
        </h2>
        <p className="text-sm text-stone-500 mb-4">
          Serving Naperville, Illinois locally — and shipping nationwide.
        </p>
        <div className="grid md:grid-cols-2 gap-3 sm:gap-4">
          <div className="bg-white border rounded-3xl p-6 sm:p-8">
            <h3 className="font-display text-xl font-bold">Local Delivery</h3>
            <p className="text-sm sm:text-[15px] text-stone-700 leading-relaxed mt-2">
              Located near Naperville, Illinois? We offer local delivery within
              approximately 2 hours of Naperville for an additional delivery fee.
              Delivery pricing varies based on distance and order requirements.
            </p>
            <p className="text-sm sm:text-[15px] text-stone-700 leading-relaxed mt-3">
              {DELIVERY_DETAILS}
            </p>
            <Link
              to="/shipping"
              className="min-h-[44px] inline-flex items-center mt-4 text-sm font-bold text-amber-700 hover:text-amber-800 underline underline-offset-4 px-1"
            >
              Local delivery information →
            </Link>
          </div>
          <div className="bg-white border rounded-3xl p-6 sm:p-8">
            <h3 className="font-display text-xl font-bold">Shipping</h3>
            <p className="text-sm sm:text-[15px] text-stone-700 leading-relaxed mt-2">
              {SHIPPING_COPY}
            </p>
            <p className="text-sm sm:text-[15px] text-stone-700 leading-relaxed mt-3">
              {SHIP_LINE} Orders ship in 1–3 business days with tracking in My
              Account → Order Tracking.
            </p>
            <Link
              to="/shop"
              className="min-h-[44px] inline-flex items-center mt-4 text-sm font-bold text-amber-700 hover:text-amber-800 underline underline-offset-4 px-1"
            >
              Shop shippable treasures →
            </Link>
          </div>
        </div>
      </section>

      {/* LOCAL PICKUP */}
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-1">
          Local Pickup
        </h2>
        <div className="bg-white border rounded-3xl p-6 sm:p-8 text-sm sm:text-[15px] text-stone-700 leading-relaxed">
          <p>{PICKUP_COPY}</p>
        </div>
      </section>

      {/* RECENTLY REHOMED */}
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="flex items-end justify-between mb-4">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold">
              Recently Rehomed
            </h2>
            <p className="text-sm text-stone-500">40+ items rehomed so far</p>
          </div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
          {(sold.length
            ? sold.slice(0, 4)
            : [
                { id: 'ph1', title: 'Rehomed treasure — photo coming soon' },
                { id: 'ph2', title: 'Rehomed treasure — photo coming soon' },
                { id: 'ph3', title: 'Rehomed treasure — photo coming soon' },
                { id: 'ph4', title: 'Rehomed treasure — photo coming soon' },
              ]
          ).map((p: any) => (
            <div
              key={p.id}
              className="bg-white rounded-2xl overflow-hidden border border-stone-200/80"
            >
              <div className="relative aspect-[4/3] bg-stone-200 flex items-center justify-center">
                {p.images?.[0] ? (
                  <img
                    src={p.images[0]}
                    alt={p.title}
                    loading="lazy"
                    className="w-full h-full object-cover grayscale"
                  />
                ) : (
                  <span className="text-xs font-bold text-stone-500 px-4 text-center">
                    [PHOTO PLACEHOLDER — {p.title}]
                  </span>
                )}
                <span className="absolute top-2 left-2 bg-stone-900 text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
                  SOLD
                </span>
              </div>
              <p className="p-3.5 text-[13px] font-semibold leading-snug line-clamp-2 min-h-[2.5rem]">
                {p.title}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* HOW ORDERING WORKS */}
      <section className="max-w-7xl mx-auto px-4 mt-14">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-1">
          How Ordering Works
        </h2>
        <p className="text-sm text-stone-500 mb-4">
          From treasure hunt to front door — in Naperville, Illinois or anywhere
          in the U.S.
        </p>
        <div className="grid sm:grid-cols-4 gap-3 sm:gap-4">
          {[
            ['1', 'Find your treasure', 'Browse the grid, filter by category, condition, and price.'],
            ['2', 'Add to cart', 'Reserve one-of-a-kind finds before someone else grabs them.'],
            ['3', 'Choose ship or local delivery', 'Ship nationwide, get Naperville-area local delivery for a fee, or pick up free.'],
            ['4', 'Check out securely', 'Cards, Apple Pay, and Google Pay via Stripe. Confirmation emailed instantly.'],
          ].map(([n, t, d]) => (
            <div key={n} className="bg-white border rounded-2xl p-5 text-center">
              <div className="w-10 h-10 mx-auto rounded-full bg-[#111] text-amber-300 font-black flex items-center justify-center">
                {n}
              </div>
              <h3 className="font-bold mt-2">{t}</h3>
              <p className="text-sm text-stone-500 mt-1">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 mt-14">
        <div className="bg-white border rounded-3xl p-6 sm:p-8">
          <div className="flex items-end justify-between gap-3 flex-wrap">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold">
                Questions, Answered
              </h2>
              <p className="text-sm text-stone-500 mt-1">
                Shipping, Naperville local delivery, returns, and pickup.
              </p>
            </div>
            <Link
              to="/faq"
              className="min-h-[44px] inline-flex items-center text-sm font-bold text-amber-700 hover:text-amber-800 underline underline-offset-4 px-2"
            >
              Read all FAQs →
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-3 mt-5 text-sm">
            {[
              ['Do you ship?', 'Yes — we ship nationwide. Costs and options are shown at checkout.'],
              ['Do you deliver locally?', 'Yes — within ~2 hours of Naperville, Illinois for an additional delivery fee based on distance and order size.'],
              ['Can I pick up?', 'Yes — free pickup in Naperville, Illinois, Sat–Sun 10am–4pm. Details emailed after checkout.'],
            ].map(([q, a]) => (
              <div key={q} className="bg-stone-50 rounded-2xl p-4">
                <p className="font-bold">{q}</p>
                <p className="text-stone-600 mt-1">{a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="bg-[#111] rounded-3xl p-8 sm:p-10 text-center border border-amber-500/20">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold"
            style={{ color: '#faf6ec' }}
          >
            Talk to a Real Human
          </h2>
          <p className="text-stone-300 text-sm mt-3 max-w-2xl mx-auto">
            Questions about an item, shipping, or Naperville-area local delivery?
            Email [EMAIL] — we reply within 24 hours.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
            <Link
              to="/contact"
              className="min-h-[44px] bg-gradient-to-r from-amber-300 to-amber-500 text-black font-extrabold px-8 py-3 rounded-full inline-flex items-center justify-center hover:brightness-110"
            >
              Contact Us
            </Link>
            <Link
              to="/shipping"
              className="min-h-[44px] border border-amber-400/60 text-amber-200 font-extrabold px-8 py-3 rounded-full inline-flex items-center justify-center hover:bg-white/10"
            >
              Shipping & Delivery
            </Link>
          </div>
        </div>
      </section>

      {/* SELL OR CONSIGN STRIP */}
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="bg-[#111] rounded-3xl p-8 sm:p-10 text-center border border-amber-500/20">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold"
            style={{ color: '#faf6ec' }}
          >
            Sell or consign to us
          </h2>
          <p className="text-stone-300 text-sm mt-3 max-w-2xl mx-auto">
            Clearing out a closet, garage, or storage unit? We buy quality
            secondhand items and take consignment. Send photos and a price to{' '}
            [EMAIL], or text [PHONE].
          </p>
        </div>
      </section>

      {/* GET FIRST DIBS */}
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="bg-black rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-30"
            style={{
              background:
                'radial-gradient(600px 300px at 50% 0%, rgba(217,180,80,0.5), transparent)',
            }}
          />
          <h2
            className="relative font-display text-2xl sm:text-3xl font-bold"
            style={{ color: '#faf6ec' }}
          >
            Get first dibs
          </h2>
          <p className="relative text-stone-400 text-sm mt-2">
            One email a week when new treasures drop. No spam, unsubscribe
            anytime.
          </p>
          <form
            onSubmit={subscribe}
            className="relative flex flex-col sm:flex-row gap-2 max-w-md mx-auto mt-5"
          >
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              required
              placeholder="you@email.com"
              className="min-h-[44px] flex-1 rounded-full px-5 py-3 text-sm bg-stone-900 border border-stone-700 text-white focus:border-amber-400 focus:outline-none"
            />
            <button className="min-h-[44px] bg-gradient-to-r from-amber-300 to-amber-500 text-black font-extrabold px-6 py-3 rounded-full text-sm">
              Notify Me
            </button>
          </form>
          {msg && <p className="relative text-amber-300 text-sm mt-3">{msg}</p>}
        </div>
      </section>
    </div>
  );
}
