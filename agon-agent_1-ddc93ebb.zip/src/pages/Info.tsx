import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Truck, ShieldCheck, Lock, Mail, ChevronDown } from 'lucide-react';
import { PICKUP_COPY, SHIP_LINE, DELIVERY_COPY, DELIVERY_DETAILS, SHIPPING_COPY } from '../lib/siteCopy';

function Shell({ title, kicker, children }: any) {
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <p className="text-xs font-bold tracking-[0.2em] uppercase text-amber-700">
        {kicker || 'ReTreasures'}
      </p>
      <h1 className="font-display text-3xl sm:text-4xl font-black mt-1">{title}</h1>
      <div className="text-sm sm:text-[15px] text-stone-700 mt-4 space-y-3 leading-relaxed">
        {children}
      </div>
    </div>
  );
}

export function ComingSoon({ title }: { title: string }) {
  return (
    <Shell title={title} kicker="ReTreasures">
      <p>Coming soon — email [EMAIL] with questions.</p>
      <p>
        <Link to="/" className="font-bold text-amber-700 underline">
          Back to home →
        </Link>
      </p>
    </Shell>
  );
}

export function About() {
  return (
    <Shell title="About ReTreasures" kicker="Our story">
      <p className="text-lg text-stone-600">Hidden Gems. Second Chances. Real Treasures.</p>
      <p>
        ReTreasures is a personal resale shop based in Naperville, Illinois: I
        hunt down quality secondhand finds — furniture, electronics, vintage,
        collectibles, and everyday treasures — photograph them, grade their
        condition honestly, and list them here ready for a new home.
      </p>
      <p>
        We serve customers locally around Naperville, Illinois — with free local
        pickup and paid local delivery within approximately 2 hours of Naperville
        — and we ship orders to customers nationwide.
      </p>
      <p>
        Every piece is one of a kind. When it&apos;s gone, it&apos;s gone — so
        check back often. You never know what you&apos;ll find at ReTreasures.
      </p>
      <p>
        <Link to="/shop" className="font-bold text-amber-700 underline">
          Start hunting →
        </Link>{' '}
        <Link to="/shipping" className="font-bold text-amber-700 underline ml-3">
          Shipping & delivery →
        </Link>
      </p>
    </Shell>
  );
}

export function Terms() {
  return (
    <Shell title="Terms of Service" kicker="The fine print">
      <p>
        <b>1. The shop.</b> ReTreasures sells secondhand inventory directly to
        customers. Each listing shows photos, price (and sale price when
        applicable), condition, quantity, SKU, and shipping/pickup options.
      </p>
      <p>
        <b>2. Payment.</b> Checkout is processed by <b>Stripe</b> (credit/debit
        cards + Apple Pay/Google Pay). We never see or store raw card numbers.
        Totals always show subtotal, discounts, tax, and shipping — no fake fees,
        ever.
      </p>
      <p>
        <b>3. Orders & fulfillment.</b> You&apos;ll get an order confirmation by
        email. {SHIP_LINE} Unclaimed pickup orders are re-listed after 7 days.
      </p>
      <p>
        <b>4. Returns.</b> 14-day returns on every purchase: unused with tags,
        buyer pays return shipping. Refunds go to the original payment method
        within 5 days of inspection.
      </p>
      <p>
        <b>5. One-of-a-kind items.</b> Quantities are real. When quantity hits
        zero, the item shows SOLD OUT.
      </p>
    </Shell>
  );
}

export function Privacy() {
  return (
    <Shell title="Privacy Policy" kicker="Your data">
      <p>
        We collect only what the shop needs: account details, orders, cart, saved
        addresses, newsletter opt-ins, and anonymized analytics (Google Analytics,
        optional). Payments run through Stripe — card numbers never touch our
        servers.
      </p>
      <p>
        We use your email for order confirmations, shipping updates, and (only if
        you opt in) marketing. We never sell personal data. Request
        export/deletion anytime at <b>[EMAIL]</b>.
      </p>
      <p>Cookies: session, cart, and analytics only.</p>
    </Shell>
  );
}

export function Shipping() {
  return (
    <Shell title="Shipping & Delivery" kicker="Naperville, Illinois — shipping nationwide">
      <p>
        <b>Local Delivery.</b> {DELIVERY_COPY}
      </p>
      <p>{DELIVERY_DETAILS}</p>
      <p>
        <b>Shipping.</b> {SHIPPING_COPY}{' '}
        <b>Flat-rate $8.99 shipping</b> — <b>FREE on orders $150+</b> (always
        shown before you pay). Orders ship in 1–3 business days with tracking in
        My Account → Order Tracking.
      </p>
      <p>
        <b>Free local pickup:</b> {PICKUP_COPY}
      </p>
      <p>
        Large furniture/appliances: freight quote or local delivery quote within
        24h, or pickup with a truck + helper. Report damage within 72h with
        photos.
      </p>
      <p>Some items are pickup- or delivery-only — each product page says exactly which options apply. Delivery availability may depend on the item, distance, schedule, and other logistical factors, so contact us if you are unsure.</p>
    </Shell>
  );
}

export function HowItWorks() {
  const steps: [string, string][] = [
    ['Find your treasure', 'Browse Shop All, New Arrivals, or Featured. Filter by category, condition, and price.'],
    ['Add to cart', 'One-of-a-kind items sell fast — adding to cart reserves yours while you check out.'],
    ['Choose ship, local delivery, or pickup', 'Ship anywhere in the U.S., choose Naperville-area local delivery (fee varies by distance and order size), or pick up free in Naperville, Illinois.'],
    ['Check out securely', 'Pay with cards, Apple Pay, or Google Pay via Stripe. Your confirmation email arrives instantly with next steps.'],
  ];
  return (
    <Shell title="How It Works" kicker="Shopping at ReTreasures">
      <p>
        ReTreasures is a resale shop based in Naperville, Illinois. Here is how
        ordering works, whether you are local or shopping from across the
        country.
      </p>
      <ol className="space-y-3">
        {steps.map(([t, d], i) => (
          <li key={t} className="bg-white border rounded-2xl p-4">
            <p className="font-bold">
              <span className="inline-flex w-6 h-6 mr-2 rounded-full bg-[#111] text-amber-300 text-xs font-black items-center justify-center">
                {i + 1}
              </span>
              {t}
            </p>
            <p className="text-stone-600 mt-1 ml-8">{d}</p>
          </li>
        ))}
      </ol>
      <p>
        <Link to="/shop" className="font-bold text-amber-700 underline">
          Start shopping →
        </Link>{' '}
        <Link to="/contact" className="font-bold text-amber-700 underline ml-3">
          Ask a question →
        </Link>
      </p>
    </Shell>
  );
}

export function Returns() {
  return (
    <Shell title="Returns" kicker="Shop with confidence — Naperville, Illinois">
      <p>
        <b>14-day returns on every purchase</b> from delivery/pickup. Items must
        be unused with tags; buyer pays return shipping. Refunds go to the
        original payment method within 5 days of inspection.
      </p>
      <p>
        Local customers around Naperville can also arrange an in-person return —
        contact us first so we can schedule it.
      </p>
      <p>
        Something wrong or damaged? Email [EMAIL] with your order number and
        photos within 72h and we&apos;ll make it right.
      </p>
    </Shell>
  );
}

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  const faqs: [string, string][] = [
    [
      'How do I buy something?',
      'Tap Add to Cart, review your cart, and check out securely with a card or digital wallet. Guest checkout works — no account needed.',
    ],
    [
      'Are there any extra fees?',
      'No fake fees, ever. You pay the item price (or sale price), any coupon discount, sales tax, and shipping — all itemized before you pay.',
    ],
    ['Ship, deliver, or pickup?', `${SHIP_LINE} ${DELIVERY_COPY} Pickups are Sat–Sun, 10am–4pm in Naperville, Illinois. Each product page shows its options.`],
    [
      'What do condition grades mean?',
      'New (Sealed), Like New, Excellent, Good, and Fair — see the Condition Grades section on the homepage. Every flaw is photographed before listing.',
    ],
    [
      'What if my item arrives damaged?',
      'Send photos within 72h to [EMAIL] — refund or replacement, your choice.',
    ],
    ['Can I return something?', 'Yes — 14 days, unused with tags. Buyer pays return shipping.'],
    [
      'How do I track my order?',
      'My Account → Order Tracking, or the Track Order page with your order number. Tracking appears as soon as it ships.',
    ],
    [
      'Where are you located?',
      'ReTreasures is based in Naperville, Illinois. We offer free local pickup, paid local delivery within approximately 2 hours of Naperville, and nationwide shipping.',
    ],
    ['Do you have coupons?', 'Try WELCOME10 at checkout. Join the email list for new-arrival and sale alerts.'],
  ];
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <p className="text-xs font-bold tracking-[0.2em] uppercase text-amber-700">Help</p>
      <h1 className="font-display text-3xl font-black mt-1">FAQ</h1>
      <div className="mt-4 space-y-2">
        {faqs.map(([q, a], i) => (
          <div key={i} className="bg-white border rounded-2xl overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="min-h-[44px] w-full flex justify-between items-center px-5 py-4 font-bold text-sm text-left"
            >
              {q}
              <ChevronDown
                className={`w-4 h-4 transition ${open === i ? 'rotate-180' : ''}`}
              />
            </button>
            {open === i && <p className="px-5 pb-4 text-sm text-stone-600">{a}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

export function Contact() {
  const [f, setF] = useState({ name: '', email: '', subject: 'General question', message: '' });
  const [msg, setMsg] = useState('');
  const send = async (e: any) => {
    e.preventDefault();
    const r = await fetch('/api/contacts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(f),
    });
    if (r.ok) {
      setMsg('Message sent! We reply within 24 hours.');
      setF({ name: '', email: '', subject: 'General question', message: '' });
    } else setMsg('Please fill name, email and message.');
  };
  return (
    <div className="max-w-3xl mx-auto px-4 py-10 grid md:grid-cols-2 gap-6">
      <div>
        <p className="text-xs font-bold tracking-[0.2em] uppercase text-amber-700">
          Get in touch
        </p>
        <h1 className="font-display text-3xl font-black mt-1 flex items-center gap-2">
          <Mail className="w-7 h-7 text-amber-600" />
          Contact
        </h1>
        <p className="text-sm text-stone-500 mt-2">
          Order help, delivery windows, item questions — we answer fast.
        </p>
        <div className="bg-white border rounded-2xl p-4 mt-4 text-sm space-y-1.5">
          <p>
            <b>Email:</b> [EMAIL]
          </p>
          <p>
            <b>Phone:</b> [PHONE]
          </p>
          <p>
            <b>Location:</b> Naperville, Illinois — shipping nationwide, local
            delivery within ~2 hours of Naperville
          </p>
          <p>
            <b>Pickup:</b> Naperville, Illinois — Sat–Sun, 10am–4pm (exact
            address emailed after checkout)
          </p>
          <p>
            <b>Response:</b> within 24 hours
          </p>
        </div>
      </div>
      <form onSubmit={send} className="bg-white border rounded-3xl p-6 space-y-3 h-fit">
        <input
          value={f.name}
          onChange={(e) => setF({ ...f, name: e.target.value })}
          placeholder="Name*"
          className="w-full min-h-[44px] border rounded-xl px-3 py-2.5 text-sm"
        />
        <input
          value={f.email}
          onChange={(e) => setF({ ...f, email: e.target.value })}
          placeholder="Email*"
          className="w-full min-h-[44px] border rounded-xl px-3 py-2.5 text-sm"
        />
        <select
          value={f.subject}
          onChange={(e) => setF({ ...f, subject: e.target.value })}
          className="w-full min-h-[44px] border rounded-xl px-3 py-2.5 text-sm"
        >
          {['General question', 'Order help', 'Item question', 'Shipping / pickup', 'Make an offer'].map(
            (s) => (
              <option key={s}>{s}</option>
            )
          )}
        </select>
        <textarea
          value={f.message}
          onChange={(e) => setF({ ...f, message: e.target.value })}
          rows={5}
          placeholder="How can we help?*"
          className="w-full border rounded-xl px-3 py-2.5 text-sm"
        />
        {msg && (
          <p className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2">
            {msg}
          </p>
        )}
        <button className="min-h-[44px] w-full bg-[#1d4d2b] text-white font-bold py-3 rounded-xl text-sm">
          Send Message
        </button>
      </form>
    </div>
  );
}

export function TrustBadges() {
  return (
    <div className="max-w-6xl mx-auto px-4 pt-6">
      <div className="grid grid-cols-3 gap-2 text-center text-[11px] text-stone-500">
        {[
          [ShieldCheck, 'Vetted & honestly graded'],
          [Truck, 'Ship or free local pickup'],
          [Lock, 'Secure checkout via Stripe'],
        ].map(([I, t]: any, i: number) => (
          <div
            key={i}
            className="bg-white/70 border rounded-full py-2.5 px-2 flex items-center justify-center gap-1 min-h-[44px]"
          >
            <I className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="truncate">{t}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
