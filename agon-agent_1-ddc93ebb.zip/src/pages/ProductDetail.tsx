import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ShoppingCart, Share2, Truck, Store, RotateCcw, ShieldCheck, Minus, Plus, Tag } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { fmt, condColor, effPrice, isSoldOut } from '../lib/utils';
import { useCart } from '../lib/shop';
import { SHIP_LINE, DELIVERY_COPY } from '../lib/siteCopy';

export default function ProductDetail() {
  const params = useParams();
  const rawId = params.id || (params as any).slug || '';
  const nav = useNavigate();
  const { add } = useCart();
  const [p, setP] = useState<any>(null);
  const [catName, setCatName] = useState('');
  const [related, setRelated] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [img, setImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState('');
  const [offer, setOffer] = useState('');
  const [offerMsg, setOfferMsg] = useState('');
  const [offerSent, setOfferSent] = useState(false);

  const slugId = String(rawId).split('-').pop();
  const id = /^\d+$/.test(String(rawId)) ? String(rawId) : slugId;

  const load = async () => {
    try {
      let d: any = null;
      const byId = await fetch(`/api/products?id=${id}`).then((x) => x.json()).catch(() => null);
      if (byId?.id) d = byId;
      if (!d?.id && String(rawId).includes('-')) {
        const all = await fetch('/api/products?limit=200').then((x) => x.json()).catch(() => []);
        if (Array.isArray(all)) {
          const slugify = (t: string) =>
            t
              .toLowerCase()
              .replace(/[^a-z0-9]+/g, '-')
              .replace(/^-+|-+$/g, '');
          d =
            all.find(
              (x: any) =>
                `${slugify(x.title || '')}-${x.id}` === String(rawId) ||
                slugify(x.title || '') === String(rawId)
            ) || null;
          if (d?.id) {
            const fresh = await fetch(`/api/products?id=${d.id}`)
              .then((x) => x.json())
              .catch(() => null);
            if (fresh?.id) d = fresh;
          }
        }
      }
      if (!d?.id) {
        setP(null);
        return;
      }
      setP(d);
      if (d?.category_id) {
        fetch('/api/categories')
          .then((x) => x.json())
          .then((cs) => {
            if (Array.isArray(cs)) {
              const c = cs.find((x: any) => x.id === d.category_id);
              if (c) setCatName(c.name);
            }
          })
          .catch(() => {});
        fetch('/api/products?status=active&limit=50')
          .then((x) => x.json())
          .then((all) => {
            if (Array.isArray(all))
              setRelated(
                all.filter((x: any) => x.category_id === d.category_id && x.id !== d.id).slice(0, 4)
              );
          })
          .catch(() => {});
      }
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    setImg(0);
    setQty(1);
    setAdded('');
    setOffer('');
    setOfferMsg('');
    setOfferSent(false);
    load();
  }, [rawId]);

  if (loading)
    return (
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="bg-white rounded-3xl h-96 animate-pulse" />
      </div>
    );
  if (!p?.id)
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <p className="text-4xl">🗺️</p>
        <p className="font-bold text-xl mt-2">Treasure not found</p>
        <Link to="/shop" className="text-amber-700 underline text-sm">
          Back to the hunt
        </Link>
      </div>
    );

  const gallery = [
    ...((p.images && p.images.length ? p.images : []) as string[]),
  ];
  while (gallery.length < 4) gallery.push('');
  const slots = gallery.slice(0, 6);
  const hasPhoto = (s: string) => !!s;
  const heroImg = hasPhoto(slots[img]) ? slots[img] : '';

  const price = effPrice(p);
  const was = parseFloat(p.price || 0);
  const onSale = p.sale_price != null && parseFloat(p.sale_price) < was;
  const sold = isSoldOut(p);
  const maxQ = Math.max(1, Math.min(p.quantity || 1, 99));
  const qtyNum = parseInt(p.quantity ?? 1);

  const doAdd = (goCart: boolean) => {
    if (sold) return;
    add({
      product_id: p.id,
      title: p.title,
      price,
      qty: Math.min(qty, maxQ),
      image: heroImg || slots.find(hasPhoto) || '',
      sku: p.sku,
    });
    if (goCart) nav('/cart');
    else {
      setAdded('Added to cart!');
      setTimeout(() => setAdded(''), 2500);
    }
  };

  const sendOffer = async (e: any) => {
    e.preventDefault();
    setOfferMsg('');
    const amt = parseFloat(offer);
    if (isNaN(amt) || amt <= 0) {
      setOfferMsg('Enter an offer amount in dollars.');
      return;
    }
    try {
      const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Offer',
          email: 'offer@retresures.com',
          subject: `Offer $${amt.toFixed(2)} on ${p.title}`,
          message: `Offer of $${amt.toFixed(2)} on item #${p.id} "${p.title}" (listed ${fmt(price)}).`,
        }),
      });
      if (res.ok) {
        setOfferSent(true);
        setOfferMsg(`Offer of ${fmt(amt)} sent! We reply within 24 hours.`);
        setOffer('');
      } else setOfferMsg('Could not send the offer — try again.');
    } catch {
      setOfferMsg('Could not send the offer — try again.');
    }
  };

  const share = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: p.title, text: 'Found this treasure on ReTreasures!', url });
      } catch {}
    } else {
      try {
        await navigator.clipboard?.writeText(url);
      } catch {}
      alert('Link copied! Share the treasure.');
    }
  };

  const shipAvail = p.shipping_available !== false;
  const pickAvail = p.pickup_available !== false;
  const included: string[] = Array.isArray(p.included)
    ? p.included
    : typeof p.included === 'string' && p.included
    ? [p.included]
    : [];
  const weight = p.weight || p.shipping_weight || '';

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <p className="text-xs text-stone-400 mb-3">
        <Link to="/" className="hover:underline">
          Home
        </Link>{' '}
        /{' '}
        <Link to="/shop" className="hover:underline">
          Shop
        </Link>
        {catName && (
          <>
            {' '}
            /{' '}
            <Link to={`/shop?category=${encodeURIComponent(catName)}`} className="hover:underline">
              {catName}
            </Link>
          </>
        )}{' '}
        / {(p.title || '').slice(0, 40)}
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <div className="bg-white rounded-3xl border overflow-hidden aspect-[4/3] relative">
            {heroImg ? (
              <img src={heroImg} alt={p.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-stone-200 flex items-center justify-center px-6 text-center">
                <span className="text-xs font-bold text-stone-500">
                  [PHOTO PLACEHOLDER — {p.title} — photo {img + 1} of {slots.length}]
                </span>
              </div>
            )}
            {sold && (
              <span className="absolute top-3 left-3 bg-stone-900 text-white text-xs font-bold px-3 py-1.5 rounded-full">
                SOLD OUT
              </span>
            )}
            {onSale && !sold && (
              <span className="absolute top-3 left-3 bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-full">
                SALE — save {fmt(was - price)}
              </span>
            )}
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-2">
            {slots.map((s: string, i: number) => (
              <button
                key={i}
                onClick={() => setImg(i)}
                className={`min-h-[44px] aspect-[4/3] rounded-xl overflow-hidden border-2 shrink-0 bg-stone-100 ${
                  i === img ? 'border-amber-500' : 'border-transparent'
                }`}
              >
                {hasPhoto(s) ? (
                  <img src={s} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-[9px] font-bold text-stone-400 px-1">
                    Photo {i + 1}
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-2 mt-4 text-center text-xs">
            <div className="bg-white border rounded-2xl p-3">
              <Truck className="w-4 h-4 mx-auto text-amber-600" />
              <p className="font-bold mt-1">Ship / Pickup</p>
              <p className="text-stone-500">$8.99 · free $150+</p>
            </div>
            <div className="bg-white border rounded-2xl p-3">
              <RotateCcw className="w-4 h-4 mx-auto text-amber-600" />
              <p className="font-bold mt-1">Returns</p>
              <p className="text-stone-500">14-day returns</p>
            </div>
            <div className="bg-white border rounded-2xl p-3">
              <ShieldCheck className="w-4 h-4 mx-auto text-amber-600" />
              <p className="font-bold mt-1">Protected</p>
              <p className="text-stone-500">Secure Stripe checkout</p>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <Link
              to="/#condition-grades"
              className={`text-xs font-bold px-2.5 py-1 rounded-full ${condColor(p.condition)}`}
            >
              {p.condition}
            </Link>
            {p.sku && (
              <span className="text-[11px] font-mono text-stone-500">SKU: {p.sku}</span>
            )}
            {sold ? (
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-stone-800 text-white ml-auto">
                SOLD OUT
              </span>
            ) : qtyNum === 1 ? (
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 ml-auto">
                Only 1 left
              </span>
            ) : (
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 ml-auto">
                In Stock
              </span>
            )}
          </div>

          <h1 className="font-display text-2xl sm:text-3xl font-black mt-2">{p.title}</h1>
          <p className="text-xs text-stone-500 mt-1">
            Available in Naperville, Illinois · ships nationwide · Naperville local delivery available
          </p>
          {(p.brand || p.model) && (
            <p className="text-sm text-stone-500 mt-1">
              {[p.brand, p.model].filter(Boolean).join(' · ')}
            </p>
          )}

          <div className="bg-white border rounded-2xl p-5 mt-4">
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-black">{fmt(price)}</p>
              {onSale && <p className="text-lg text-stone-400 line-through">{fmt(was)}</p>}
            </div>
            <p className="text-xs text-stone-500 mt-1">
              + tax & shipping calculated at checkout · clear pricing, no fake fees · local delivery quoted by distance
            </p>
            {sold ? (
              <div className="mt-3 bg-stone-100 border rounded-xl py-3.5 text-center font-extrabold text-stone-500">
                SOLD OUT
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mt-3">
                  <span className="text-sm font-bold">Qty</span>
                  <div className="flex items-center border rounded-xl overflow-hidden">
                    <button
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                      className="min-h-[44px] min-w-[44px] px-3 py-2 hover:bg-stone-100"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-10 text-center font-bold">{qty}</span>
                    <button
                      onClick={() => setQty((q) => Math.min(maxQ, q + 1))}
                      className="min-h-[44px] min-w-[44px] px-3 py-2 hover:bg-stone-100"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <span className="text-xs text-stone-400">{maxQ} available</span>
                </div>
                <button
                  onClick={() => doAdd(false)}
                  className="min-h-[44px] w-full mt-3 bg-[#1d4d2b] text-white font-extrabold py-3.5 rounded-xl flex items-center justify-center gap-2 hover:brightness-110"
                >
                  <ShoppingCart className="w-5 h-5" />
                  Add to cart
                </button>
                {added && (
                  <p className="text-sm text-emerald-700 font-bold mt-2 text-center">{added}</p>
                )}
                <form onSubmit={sendOffer} className="mt-2 flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input
                      value={offer}
                      onChange={(e) => setOffer(e.target.value)}
                      type="number"
                      step="0.01"
                      min={1}
                      placeholder="Make an offer $"
                      disabled={offerSent}
                      className="w-full min-h-[44px] border rounded-xl pl-9 pr-3 py-2.5 text-sm"
                    />
                  </div>
                  <button
                    disabled={offerSent}
                    className="min-h-[44px] border border-stone-300 font-bold px-4 rounded-xl text-sm disabled:opacity-50"
                  >
                    {offerSent ? 'Sent' : 'Offer'}
                  </button>
                </form>
                {offerMsg && (
                  <p
                    className={`text-xs font-bold mt-2 text-center ${
                      offerSent ? 'text-emerald-700' : 'text-red-600'
                    }`}
                  >
                    {offerMsg}
                  </p>
                )}
              </>
            )}
            <button
              onClick={share}
              className="min-h-[44px] w-full mt-2 border border-stone-300 rounded-xl py-2.5 text-sm font-bold flex items-center justify-center gap-1.5 bg-white"
            >
              <Share2 className="w-4 h-4" />
              Share this find
            </button>
          </div>

          <div className="bg-white border rounded-2xl p-5 mt-4 space-y-3 text-sm">
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest text-stone-400 mb-1">
                Description
              </h4>
              <p className="text-stone-700 whitespace-pre-line">
                {p.description || '[ITEM DESCRIPTION — details coming soon]'}
              </p>
            </div>
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest text-stone-400 mb-1">
                What&apos;s included
              </h4>
              {included.length ? (
                <ul className="list-disc ml-5 text-stone-700">
                  {included.map((x, i) => (
                    <li key={i}>{x}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-stone-500 text-[13px]">
                  [WHAT&apos;S INCLUDED — list accessories, parts, and paperwork here]
                </p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 text-[13px]">
              {p.brand && (
                <div className="bg-stone-50 rounded-xl p-3">
                  <span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">
                    Brand
                  </span>
                  {p.brand}
                </div>
              )}
              {p.model && (
                <div className="bg-stone-50 rounded-xl p-3">
                  <span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">
                    Model
                  </span>
                  {p.model}
                </div>
              )}
              <div className="bg-stone-50 rounded-xl p-3">
                <span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">
                  Dimensions / weight
                </span>
                {[p.dimensions, weight].filter(Boolean).join(' · ') ||
                  '[DIMENSIONS/WEIGHT — add measurements here]'}
              </div>
              {catName && (
                <div className="bg-stone-50 rounded-xl p-3">
                  <span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">
                    Category
                  </span>
                  {catName}
                </div>
              )}
              <div className="bg-stone-50 rounded-xl p-3">
                <span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">
                  Availability
                </span>
                {sold ? 'Sold out' : `${p.quantity || 1} in stock`}
              </div>
              <div className="bg-stone-50 rounded-xl p-3">
                <span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">
                  Fulfillment
                </span>
                {[shipAvail && 'Ships nationwide', 'Naperville-area local delivery (fee varies)', pickAvail && 'Free local pickup']
                  .filter(Boolean)
                  .join(' · ')}
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="bg-stone-50 rounded-xl p-3">
                <h4 className="font-bold text-xs flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5" />
                  Shipping
                </h4>
                <p className="text-stone-600 mt-1 text-[13px]">
                  {p.shipping_info ||
                    (shipAvail
                      ? SHIP_LINE + ' Tracking provided.'
                      : 'This item is local pickup or delivery only.')}
                </p>
              </div>
              <div className="bg-stone-50 rounded-xl p-3">
                <h4 className="font-bold text-xs flex items-center gap-1">
                  <Store className="w-3.5 h-3.5" />
                  Local pickup & delivery
                </h4>
                <p className="text-stone-600 mt-1 text-[13px]">
                  {p.pickup_info ||
                    (pickAvail
                      ? 'Free pickup in Naperville, Illinois — Sat–Sun, 10am–4pm. Details emailed after checkout.'
                      : 'Pickup not available for this item.')}
                </p>
                <p className="text-stone-600 mt-1.5 text-[13px]">
                  <Link to="/shipping" className="font-bold text-amber-700 underline">
                    {DELIVERY_COPY}
                  </Link>
                </p>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest text-stone-400 mb-1">
                Returns
              </h4>
              <p className="text-stone-600 text-[13px]">
                {p.return_info ||
                  '14-day returns on every purchase. Unused with tags; buyer pays return shipping.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-8">
          <h3 className="font-display text-xl font-bold mb-3">You may also fancy</h3>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
            {related.map((r: any) => (
              <ProductCard key={r.id} p={r} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
