import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Package, MapPin, User, Settings, LogOut, Loader2 } from 'lucide-react';
import { fmt } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';
export default function Account() {
  const { user, loading, signOut } = useAuth();
  const nav = useNavigate();
  const [tab, setTab] = useState('orders');
  const [orders, setOrders] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  const [busy, setBusy] = useState(true);
  const [addr, setAddr] = useState({ address: '', city: '', state: '', zip: '' });
  const [phone, setPhone] = useState('');
  useEffect(() => {
    if (loading) return;
    if (!user) { nav('/login'); return; }
    (async () => {
      setBusy(true);
      try {
        const em = encodeURIComponent(user.email);
        const [o, prof] = await Promise.all([
          fetch(`/api/orders?email=${em}`).then(r => r.json()).catch(() => []),
          fetch(`/api/profiles?email=${em}`).then(r => r.json()).catch(() => [])
        ]);
        setOrders(Array.isArray(o) ? o : []);
        if (Array.isArray(prof) && prof[0]) {
          setProfile(prof[0]);
          const a = (prof[0].addresses || [])[0] || {};
          setAddr({ address: a.line || a.address || '', city: a.city || '', state: a.state || '', zip: a.zip || '' });
          setPhone(prof[0].phone || '');
        }
      } catch {} finally { setBusy(false); }
    })();
  }, [loading, user?.email]);
  if (loading || !user) return <div className="max-w-3xl mx-auto px-4 py-16 text-center"><Loader2 className="w-6 h-6 animate-spin mx-auto" /><p className="text-sm text-stone-500 mt-2">Loading your account...</p></div>;
  const save = async () => {
    await fetch('/api/profiles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: user.email, user_id: user.id, name: user.name, phone, addresses: [{ ...addr, line: `${addr.address}, ${addr.city} ${addr.zip}`.trim() }] }) });
    alert('Account saved!');
  };
  const tabs: any[] = [['orders', `Orders (${orders.length})`, Package], ['tracking', 'Order Tracking', MapPin], ['account', 'Account Info', User], ['settings', 'Addresses & Settings', Settings]];
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-gradient-to-r from-[#141210] to-[#2a2010] rounded-3xl p-6 sm:p-8 flex items-center gap-4 border border-amber-500/20">
        <span className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-300 to-amber-600 flex items-center justify-center text-2xl font-black text-black">{(user.name || user.email)[0].toUpperCase()}</span>
        <div className="flex-1 min-w-0"><h1 className="font-display text-2xl font-black truncate" style={{ color: '#faf6ec' }}>{user.name || 'Treasure Hunter'}</h1><p className="text-sm text-stone-400 truncate">{user.email}</p></div>
        <button onClick={async () => { await signOut(); nav('/'); }} className="text-xs border border-stone-600 text-stone-300 rounded-full px-4 py-2 flex items-center gap-1 hover:border-amber-400 shrink-0"><LogOut className="w-3.5 h-3.5" />Sign out</button>
      </div>
      <div className="flex gap-2 mt-5 overflow-x-auto pb-1">{tabs.map(([k, l, Icon]: any) => <button key={k} onClick={() => setTab(k)} className={`flex items-center gap-1.5 px-4 py-2.5 rounded-full text-sm font-bold whitespace-nowrap border ${tab === k ? 'bg-black text-amber-300 border-black' : 'bg-white border-stone-200'}`}><Icon className="w-4 h-4" />{l}</button>)}</div>
      {busy ? <div className="bg-white rounded-2xl h-48 animate-pulse mt-4" /> : (
        <div className="mt-4 space-y-3">
          {tab === 'orders' && (orders.length === 0 ? <Empty t="No orders yet" d="Your purchases will show up here with status and tracking." /> : orders.map(o => (
            <div key={o.id} className="bg-white border rounded-2xl p-4">
              <div className="flex justify-between items-center flex-wrap gap-2"><p className="font-bold text-sm">{o.order_number} · {fmt(o.total)}</p><span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 uppercase">{o.status}{o.tracking_number ? ' · ' + o.tracking_number : ''}</span></div>
              <p className="text-xs text-stone-500 mt-1">{(o.items || []).map((i: any) => `${i.title} ×${i.qty}`).join(' · ')} — {o.created_at ? new Date(o.created_at).toLocaleDateString() : ''}</p>
              <Link to="/track" className="text-xs font-bold text-amber-700 underline mt-1 inline-block">Track this order →</Link>
            </div>)))}
          {tab === 'tracking' && (
            <div className="bg-white border rounded-2xl p-5 text-sm">
              <p className="text-stone-600">Full live tracking lives on the dedicated page.</p>
              <Link to="/track" className="inline-block mt-3 bg-black text-amber-300 text-sm font-bold px-5 py-2.5 rounded-full">Open Order Tracking</Link>
            </div>)}
          {tab === 'account' && (
            <div className="bg-white border rounded-2xl p-5 space-y-3 max-w-xl text-sm">
              <div className="bg-stone-50 rounded-xl p-3"><span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">Name</span>{user.name || '—'}</div>
              <div className="bg-stone-50 rounded-xl p-3"><span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">Email</span>{user.email}</div>
              <div className="bg-stone-50 rounded-xl p-3"><span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">Phone</span>{phone || profile?.phone || '—'}</div>
              <div className="bg-stone-50 rounded-xl p-3"><span className="font-bold text-xs uppercase tracking-widest text-stone-400 block">Total orders</span>{orders.length}</div>
            </div>)}
          {tab === 'settings' && (
            <div className="bg-white border rounded-2xl p-5 space-y-3 max-w-xl text-sm">
              <label className="block font-bold text-sm">Phone<input value={phone} onChange={e => setPhone(e.target.value)} placeholder="(555) 123-4567" className="mt-1 w-full border rounded-xl px-3 py-2 font-normal" /></label>
              <label className="block font-bold text-sm">Saved shipping address<input value={addr.address} onChange={e => setAddr({ ...addr, address: e.target.value })} placeholder="Street address" className="mt-1 w-full border rounded-xl px-3 py-2 font-normal" /></label>
              <div className="grid grid-cols-3 gap-2">
                <input value={addr.city} onChange={e => setAddr({ ...addr, city: e.target.value })} placeholder="City" className="border rounded-xl px-3 py-2 font-normal" />
                <input value={addr.state} onChange={e => setAddr({ ...addr, state: e.target.value })} placeholder="State" className="border rounded-xl px-3 py-2 font-normal" />
                <input value={addr.zip} onChange={e => setAddr({ ...addr, zip: e.target.value })} placeholder="ZIP" className="border rounded-xl px-3 py-2 font-normal" />
              </div>
              <button onClick={save} className="bg-black text-amber-300 text-sm font-bold px-6 py-3 rounded-xl">Save Settings</button>
              <p className="text-[11px] text-stone-400">Payments are processed securely by Stripe — we never store card numbers.</p>
            </div>)}
        </div>
      )}
    </div>
  );
}
function Empty({ t, d }: any) { return <div className="bg-white border rounded-2xl p-10 text-center"><p className="font-bold">{t}</p><p className="text-sm text-stone-500">{d}</p><Link to="/shop" className="inline-block mt-3 text-sm font-bold bg-black text-amber-300 px-5 py-2.5 rounded-full">Shop All</Link></div>; }
