import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Minus, Plus, ArrowRight, ShoppingBag } from 'lucide-react';
import { fmt } from '../lib/utils';
import { useCart } from '../lib/shop';
export default function Cart() {
  const { cart, updateQty, remove, clear, subtotal } = useCart();
  const nav = useNavigate();
  if (!cart.length) return (
    <div className="max-w-xl mx-auto px-4 py-16 text-center">
      <p className="text-5xl">🛒</p>
      <h1 className="font-display text-2xl font-black mt-3">Your treasure chest is empty</h1>
      <p className="text-sm text-stone-500 mt-1">You never know what you'll find — go take a look.</p>
      <Link to="/shop" className="inline-flex items-center gap-2 mt-5 min-h-[44px] bg-black text-amber-300 font-bold px-6 py-3 rounded-full text-sm"><ShoppingBag className="w-4 h-4" />Find Treasures</Link>
    </div>
  );
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 grid md:grid-cols-[1fr_340px] gap-6">
      <div>
        <div className="flex items-center justify-between">
          <h1 className="font-display text-3xl font-black">Your Cart ({cart.reduce((s, i) => s + i.qty, 0)})</h1>
          <button onClick={clear} className="min-h-[44px] text-xs underline text-stone-500 px-2">Clear cart</button>
        </div>
        <div className="bg-white border rounded-2xl p-4 sm:p-5 mt-4 space-y-3">
          {cart.map(i => (
            <div key={i.product_id} className="flex gap-3 items-center border-b border-stone-100 pb-3 last:border-0 last:pb-0">
              <Link to={`/products/${(i.title || 'item').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60)}-${i.product_id}`}><img src={i.image} alt="" className="w-20 h-20 rounded-xl object-cover bg-stone-100" /></Link>
              <div className="flex-1 min-w-0">
                <Link to={`/products/${(i.title || 'item').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60)}-${i.product_id}`} className="text-sm font-bold hover:underline line-clamp-2">{i.title}</Link>
                {i.sku && <p className="text-[11px] font-mono text-stone-400">SKU: {i.sku}</p>}
                <p className="text-sm font-extrabold mt-0.5">{fmt(i.price)} <span className="text-xs font-normal text-stone-400">each</span></p>
                <div className="flex items-center gap-2 mt-1.5">
                  <div className="flex items-center border rounded-lg overflow-hidden">
                    <button onClick={() => updateQty(i.product_id, i.qty - 1)} className="min-h-[44px] min-w-[44px] px-2.5 py-1.5 hover:bg-stone-100 flex items-center justify-center"><Minus className="w-3.5 h-3.5" /></button>
                    <span className="w-8 text-center text-sm font-bold">{i.qty}</span>
                    <button onClick={() => updateQty(i.product_id, i.qty + 1)} className="min-h-[44px] min-w-[44px] px-2.5 py-1.5 hover:bg-stone-100 flex items-center justify-center"><Plus className="w-3.5 h-3.5" /></button>
                  </div>
                  <button onClick={() => remove(i.product_id)} className="min-h-[44px] text-xs text-red-500 flex items-center gap-1 underline px-1"><Trash2 className="w-3.5 h-3.5" />Remove</button>
                </div>
              </div>
              <p className="font-extrabold text-sm shrink-0">{fmt(i.price * i.qty)}</p>
            </div>
          ))}
        </div>
        <Link to="/shop" className="inline-flex items-center min-h-[44px] mt-3 text-sm font-bold text-amber-700 underline">← Keep hunting</Link>
      </div>
      <div className="bg-[#141210] text-stone-200 rounded-2xl p-5 h-fit md:sticky md:top-24">
        <h3 className="font-display font-bold text-lg text-amber-300">Cart Summary</h3>
        <div className="flex justify-between text-sm mt-3"><span className="text-stone-400">Subtotal</span><span className="font-bold">{fmt(subtotal)}</span></div>
        <p className="text-[11px] text-stone-500 mt-1">Shipping + taxes calculated at checkout. Clear pricing — no fake fees, ever.</p>
        <button onClick={() => nav('/checkout')} className="min-h-[44px] w-full mt-4 bg-gradient-to-r from-amber-300 to-amber-500 text-black font-extrabold py-3.5 rounded-xl flex items-center justify-center gap-2">Proceed to Checkout<ArrowRight className="w-4 h-4" /></button>
      </div>
    </div>
  );
}
