import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Trash2, Tag, Lock, Loader2, User } from 'lucide-react';
import { fmt } from '../lib/utils';
import { useCart } from '../lib/shop';
import { useAuth } from '../contexts/AuthContext';
export default function Checkout() {
  const { cart, remove, clear } = useCart();
  const { user } = useAuth();
  const nav = useNavigate();
  const [quote, setQuote] = useState<any>(null);
  const [coupon, setCoupon] = useState('');
  const [applied, setApplied] = useState('');
  const [fulfillment, setFulfillment] = useState<'ship' | 'delivery' | 'pickup'>('ship');
  const [form, setForm] = useState({ name: '', email: '', phone: '', address: '', city: '', state: '', zip: '', card: '', exp: '', cvc: '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [done, setDone] = useState<any>(null);
  useEffect(() => { if (user) setForm(f => ({ ...f, name: f.name || user.name || '', email: f.email || user.email || '' })); }, [user]);
  const getQuote = async (cpn = applied) => {
    if (!cart.length) return;
    try {
      const res = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: cart, coupon_code: cpn || undefined, fulfillment }) });
      const d = await res.json();
      if (res.ok) setQuote(d);
    } catch {}
  };
  useEffect(() => { getQuote(); }, [cart.length, fulfillment, applied]);
  const pay = async (e: any) => {
    e.preventDefault(); setErr('');
    if (!form.name || !form.email.includes('@')) { setErr('Name and valid email are required.'); return; }
    if (fulfillment !== 'pickup' && (!form.address || !form.city || !form.zip)) { setErr('A delivery address is required for shipped and local-delivery orders (or choose free pickup).'); return; }
    if (!/^[0-9 ]{12,19}$/.test(form.card)) { setErr('Enter a valid card number (demo: 4242 4242 4242 4242). Raw card data goes only to the payment processor — never stored.'); return; }
    if (!quote) { setErr('Could not price your order. Try again.'); return; }
    setBusy(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_name: form.name, customer_email: form.email, user_id: user?.id || null,
          items: quote.items, subtotal: quote.subtotal, tax: quote.tax, shipping: quote.shipping,
          fees: 0, discount: quote.discount, total: quote.total, status: 'paid',
          payment_method: 'card (Stripe)', payment_status: 'paid',
          shipping_address: { address: form.address, city: form.city, state: form.state, zip: form.zip, phone: form.phone, fulfillment }, coupon_code: applied || null
        })
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Order failed');
      setDone(d); clear();
    } catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };
  if (done) return (
    <div className="max-w-xl mx-auto px-4 py-14 text-center">
      <div className="bg-white rounded-3xl border p-10">
        <p className="text-5xl">🎉</p><h1 className="font-display text-3xl font-black mt-3">Order Confirmed!</h1>
        <p className="text-sm text-stone-500 mt-2">Order <b>{done.order_number}</b> · {fmt(done.total)} · confirmation sent to {done.customer_email}</p>
        <p className="text-sm text-stone-500 mt-1">{fulfillment === 'pickup' ? 'Free pickup in Naperville, Illinois — Sat–Sun, 10am–4pm. Details emailed after checkout.' : fulfillment === 'delivery' ? '[STRING_PLACEHOLDER_1]' : 'Tracking will appear under My Account → Order Tracking as soon as it ships.'}</p>
        <div className="flex gap-2 justify-center mt-6 flex-wrap"><Link to="/shop" className="bg-black text-amber-300 font-bold px-6 py-3 rounded-full text-sm">Keep Hunting</Link><Link to="/track" className="border font-bold px-6 py-3 rounded-full text-sm">Track Order</Link><Link to="/account" className="border font-bold px-6 py-3 rounded-full text-sm">My Account</Link></div>
      </div>
    </div>
  );
  if (!cart.length) return <div className="max-w-xl mx-auto px-4 py-16 text-center"><p className="text-5xl">🛒</p><h1 className="font-display text-2xl font-bold mt-3">Your treasure chest is empty</h1><Link to="/shop" className="inline-block mt-4 bg-black text-amber-300 font-bold px-6 py-3 rounded-full text-sm">Find Treasures</Link></div>;
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 grid md:grid-cols-[1fr_380px] gap-6">
      <div>
        <h1 className="font-display text-3xl font-black">Secure Checkout</h1>
        <p className="text-xs text-stone-500 mt-1 flex items-center gap-1"><Lock className="w-3.5 h-3.5" /> Guest or account checkout · Stripe (cards + Apple Pay / Google Pay) · we never store card numbers.</p>
        {!user && <p className="text-xs mt-2 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 flex items-center gap-1.5"><User className="w-3.5 h-3.5" /> Checking out as guest — or <Link to="/login" className="font-bold underline">sign in</Link> to track orders faster.</p>}
        <div className="bg-white border rounded-2xl p-5 mt-4 space-y-2">
          {cart.map(i => <div key={i.product_id} className="flex gap-3 items-center border-b border-stone-100 pb-2 last:border-0"><img src={i.image} alt="" className="w-14 h-14 rounded-xl object-cover" /><div className="flex-1 min-w-0"><p className="text-sm font-bold truncate">{i.title}</p><p className="text-xs text-stone-500">Qty {i.qty} · {fmt(i.price)}</p></div><button onClick={() => remove(i.product_id)} className="text-red-500"><Trash2 className="w-4 h-4" /></button></div>)}
        </div>
        <form onSubmit={pay} className="bg-white border rounded-2xl p-5 mt-4 space-y-3">
          <h3 className="font-bold">Billing & contact</h3>
          <div className="grid sm:grid-cols-2 gap-2">
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Full name*" className="border rounded-xl px-3 py-2.5 text-sm" />
            <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="Email*" className="border rounded-xl px-3 py-2.5 text-sm" />
          </div>
          <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Phone (for pickup/shipping updates)" className="w-full border rounded-xl px-3 py-2.5 text-sm" />
          <h3 className="font-bold pt-1">How would you like your order?</h3>
          <div className="grid grid-cols-3 gap-2">
            <button type="button" onClick={() => setFulfillment('ship')} className={`min-h-[44px] border rounded-xl py-2.5 text-sm font-bold ${fulfillment === 'ship' ? 'border-amber-500 bg-amber-50' : ''}`}>Ship it</button>
            <button type="button" onClick={() => setFulfillment('delivery')} className={`min-h-[44px] border rounded-xl py-2.5 text-sm font-bold ${fulfillment === 'delivery' ? 'border-amber-500 bg-amber-50' : ''}`}>Local delivery</button>
            <button type="button" onClick={() => setFulfillment('pickup')} className={`min-h-[44px] border rounded-xl py-2.5 text-sm font-bold ${fulfillment === 'pickup' ? 'border-amber-500 bg-amber-50' : ''}`}>Free pickup</button>
          </div>
          {fulfillment === 'delivery' && (
            <p className="text-xs text-stone-600 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
              Naperville-area local delivery (within ~2 hours of Naperville, Illinois) for an additional delivery fee. Pricing varies by distance and order size — we will confirm the exact delivery cost with you before dispatch. Availability depends on the item, distance, and schedule. Questions? <Link to="/contact" className="font-bold underline">Contact us</Link>.
            </p>
          )}
          {fulfillment === 'pickup' && (
            <p className="text-xs text-stone-600 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2">
              Free pickup in Naperville, Illinois — Sat–Sun, 10am–4pm. We email the exact pickup address and window after checkout.
            </p>
          )}
          {(fulfillment === 'ship' || fulfillment === 'delivery') && (
            <>
              <h3 className="font-bold pt-1">{fulfillment === 'delivery' ? 'Delivery address' : 'Shipping address'}</h3>
              <input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="Street address*" className="w-full min-h-[44px] border rounded-xl px-3 py-2.5 text-sm" />
              <div className="grid grid-cols-3 gap-2"><input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} placeholder="City*" className="min-h-[44px] border rounded-xl px-3 py-2.5 text-sm" /><input value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} placeholder="State" className="min-h-[44px] border rounded-xl px-3 py-2.5 text-sm" /><input value={form.zip} onChange={e => setForm({ ...form, zip: e.target.value })} placeholder="ZIP*" className="min-h-[44px] border rounded-xl px-3 py-2.5 text-sm" /></div>
            </>
          )}
          <h3 className="font-bold pt-2">Payment (demo mode — use 4242...)</h3>
          <input value={form.card} onChange={e => setForm({ ...form, card: e.target.value })} inputMode="numeric" placeholder="Card number  4242 4242 4242 4242" className="w-full border rounded-xl px-3 py-2.5 text-sm font-mono" />
          <div className="grid grid-cols-2 gap-2"><input value={form.exp} onChange={e => setForm({ ...form, exp: e.target.value })} placeholder="MM / YY" className="border rounded-xl px-3 py-2.5 text-sm font-mono" /><input value={form.cvc} onChange={e => setForm({ ...form, cvc: e.target.value })} placeholder="CVC" className="border rounded-xl px-3 py-2.5 text-sm font-mono" /></div>
          {err && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-xl px-3 py-2">{err}</p>}
          <button disabled={busy} className="min-h-[44px] w-full bg-[#1d4d2b] text-white font-extrabold py-3.5 rounded-xl flex items-center justify-center gap-2">{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}{quote ? `Secure checkout — cards, Apple Pay, Google Pay · ${fmt(quote.total)}` : 'Secure checkout — cards, Apple Pay, Google Pay'}</button>
        </form>
      </div>
      <div className="bg-[#141210] text-stone-200 rounded-2xl p-5 h-fit md:sticky md:top-24">
        <h3 className="font-display font-bold text-lg text-amber-300">Order Summary</h3>
        <div className="flex gap-2 mt-3"><input value={coupon} onChange={e => setCoupon(e.target.value)} placeholder="Coupon (try WELCOME10)" className="flex-1 bg-stone-900 border border-stone-700 rounded-xl px-3 py-2 text-sm min-w-0" /><button type="button" onClick={() => setApplied(coupon.trim().toUpperCase())} className="border border-amber-400/50 text-amber-300 text-sm font-bold px-3 rounded-xl flex items-center gap-1 shrink-0"><Tag className="w-3.5 h-3.5" />Apply</button></div>
        {applied && <p className="text-xs text-amber-300 mt-1">Applied: {applied} <button onClick={() => { setApplied(''); setCoupon(''); }} className="underline ml-1">remove</button></p>}
        {!quote ? <p className="text-sm text-stone-500 mt-4">Calculating totals...</p> : (
          <dl className="text-sm mt-4 space-y-1.5">
            <div className="flex justify-between"><dt className="text-stone-400">Subtotal</dt><dd>{fmt(quote.subtotal)}</dd></div>
            {quote.discount > 0 && <div className="flex justify-between text-emerald-400"><dt>Coupon {applied}</dt><dd>-{fmt(quote.discount)}</dd></div>}
            <div className="flex justify-between"><dt className="text-stone-400">Tax ({(quote.tax_rate * 100).toFixed(2)}%)</dt><dd>{fmt(quote.tax)}</dd></div>
            <div className="flex justify-between"><dt className="text-stone-400">Shipping{fulfillment === 'pickup' ? ' (pickup)' : fulfillment === 'delivery' ? ' (local delivery — confirmed after order)' : ''}</dt><dd>{fulfillment !== 'ship' ? (quote.shipping === 0 ? 'FREE' : fmt(quote.shipping)) + (fulfillment === 'delivery' ? '*' : '') : quote.shipping === 0 ? 'FREE' : fmt(quote.shipping)}</dd></div>
            <div className="flex justify-between border-t border-stone-700 pt-2 text-lg font-extrabold text-amber-300"><dt>Total</dt><dd>{fmt(quote.total)}</dd></div>
          </dl>
        )}
        {fulfillment === 'delivery' && <p className="text-[11px] text-amber-200/80 mt-2">*Local delivery fee confirmed by distance and order size — we will contact you with the exact cost before dispatch.</p>}
        <p className="text-[11px] text-stone-500 mt-3">All charges shown before you pay. No fake fees — subtotal, discount, tax, and shipping only.</p>
        <button onClick={() => nav('/login')} className="text-xs underline text-stone-500 mt-2">Create an account to save your cart for later.</button>
      </div>
    </div>
  );
}
