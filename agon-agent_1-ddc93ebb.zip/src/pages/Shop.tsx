import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { CAT_TILES } from '../lib/catMeta';
import { effPrice, isSoldOut } from '../lib/utils';

const CONDS = ['New (Sealed)', 'Like New', 'Excellent', 'Good', 'Fair'];

export default function Shop() {
  const [params, setParams] = useSearchParams();
  const [products, setProducts] = useState<any[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showF, setShowF] = useState(false);
  const category = params.get('category') || '';
  const search = params.get('search') || '';
  const cond = params.get('cond') || '';
  const priceBand = params.get('price') || '';
  const sort = params.get('sort') || 'new';
  const availOnly = params.get('avail') || '';

  const featuredOnly = params.get('featured') || '';

  useEffect(() => {
    setLoading(true);
    fetch('/api/products?status=active&limit=200')
      .then((r) => r.json())
      .then((d) => setProducts(Array.isArray(d) ? d : []))
      .catch(() => {})
      .finally(() => setLoading(false));
    fetch('/api/categories')
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d)) setCats(d);
      })
      .catch(() => {});
  }, []);

  const set = (k: string, v: string) => {
    const n = new URLSearchParams(params);
    if (v) n.set(k, v);
    else n.delete(k);
    setParams(n);
  };

  const catId = useMemo(
    () => cats.find((c: any) => c.name === category)?.id,
    [cats, category]
  );

  const items = useMemo(() => {
    let list = [...products];
    if (category && !catId && cats.length) return [];
    if (catId) list = list.filter((p) => p.category_id === catId);
    if (search)
      list = list.filter((p) =>
        (p.title + ' ' + (p.description || '') + ' ' + (p.brand || '') + ' ' + (p.sku || ''))
          .toLowerCase()
          .includes(search.toLowerCase())
      );
    if (cond) list = list.filter((p) => p.condition === cond);
    if (priceBand === 'under25') list = list.filter((p) => effPrice(p) < 25);
    if (priceBand === '25-50')
      list = list.filter((p) => effPrice(p) >= 25 && effPrice(p) <= 50);
    if (priceBand === '50-150')
      list = list.filter((p) => effPrice(p) > 50 && effPrice(p) <= 150);
    if (priceBand === '150plus') list = list.filter((p) => effPrice(p) > 150);
    if (availOnly === 'in') list = list.filter((p) => !isSoldOut(p));
    if (featuredOnly === '1') list = list.filter((p) => p.featured);
    if (sort === 'low') list.sort((a, b) => effPrice(a) - effPrice(b));
    else if (sort === 'high') list.sort((a, b) => effPrice(b) - effPrice(a));
    else
      list.sort(
        (a, b) =>
          new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()
      );
    return list;
  }, [products, catId, category, cats.length, search, cond, priceBand, sort, availOnly, featuredOnly]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-black">{featuredOnly === '1' ? 'Featured Treasures' : sort === 'new' && !category && !search && !cond && !priceBand ? 'New Arrivals' : 'Shop All Treasures'}</h1>
          <p className="text-sm text-stone-500">
            {items.length} treasures · resale in Naperville, Illinois · shipping nationwide
          </p>
        </div>
        <button
          onClick={() => setShowF(!showF)}
          className="min-h-[44px] sm:hidden flex items-center gap-1 border rounded-full px-4 py-2 text-sm font-bold bg-white"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filters
        </button>
      </div>
      <div className="grid lg:grid-cols-[240px_1fr] gap-6 mt-5">
        <aside
          className={`${
            showF ? 'block' : 'hidden'
          } sm:block bg-white rounded-2xl border p-5 h-fit lg:sticky lg:top-24 space-y-5 text-sm`}
        >
          <div>
            <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-stone-400">
              Search
            </h4>
            <input
              defaultValue={search}
              key={search}
              onChange={(e) => set('search', e.target.value)}
              placeholder="Name or keyword..."
              className="w-full min-h-[44px] border rounded-xl px-3 py-2"
            />
          </div>
          <div>
            <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-stone-400">
              Category
            </h4>
            <div className="space-y-1">
              {['', ...CAT_TILES.map((c) => c.name)].map((c) => (
                <button
                  key={c || 'all'}
                  onClick={() => set('category', c)}
                  className={`min-h-[44px] block w-full text-left px-3 py-1.5 rounded-lg ${
                    category === c
                      ? 'bg-black text-amber-300 font-bold'
                      : 'hover:bg-stone-100'
                  }`}
                >
                  {c || 'All categories'}
                </button>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-stone-400">
              Condition
            </h4>
            {['', ...CONDS].map((c) => (
              <button
                key={c}
                onClick={() => set('cond', c)}
                className={`min-h-[44px] mr-1.5 mb-1.5 px-3 py-1 rounded-full border text-xs ${
                  cond === c
                    ? 'bg-amber-400 border-amber-400 font-bold'
                    : 'border-stone-200'
                }`}
              >
                {c || 'Any'}
              </button>
            ))}
          </div>
          <div>
            <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-stone-400">
              Price
            </h4>
            {[
              ['', 'Any price'],
              ['under25', 'Under $25'],
              ['25-50', '$25–$50'],
              ['50-150', '$50–$150'],
              ['150plus', '$150+'],
            ].map(([v, l]) => (
              <button
                key={v}
                onClick={() => set('price', v)}
                className={`min-h-[44px] block w-full text-left px-3 py-1.5 rounded-lg ${
                  priceBand === v
                    ? 'bg-black text-amber-300 font-bold'
                    : 'hover:bg-stone-100'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          <div>
            <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-stone-400">
              Availability
            </h4>
            {[
              ['', 'All items'],
              ['in', 'In stock only'],
            ].map(([v, l]) => (
              <button
                key={v}
                onClick={() => set('avail', v)}
                className={`min-h-[44px] block w-full text-left px-3 py-1.5 rounded-lg ${
                  (availOnly || '') === v
                    ? 'bg-black text-amber-300 font-bold'
                    : 'hover:bg-stone-100'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          <div>
            <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-stone-400">
              Sort
            </h4>
            <select
              value={sort}
              onChange={(e) => set('sort', e.target.value)}
              className="w-full min-h-[44px] border rounded-xl px-3 py-2"
            >
              <option value="new">Newest</option>
              <option value="low">Price low-high</option>
              <option value="high">Price high-low</option>
            </select>
          </div>
          <button
            onClick={() => setParams({})}
            className="min-h-[44px] text-xs underline text-stone-500 px-2"
          >
            Clear all filters
          </button>
        </aside>
        <div>
          {loading ? (
            <div className="grid grid-cols-2 xl:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-white rounded-2xl h-64 animate-pulse" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="bg-white rounded-3xl border p-12 text-center">
              <p className="text-4xl">🔍</p>
              <p className="font-bold mt-2">No treasures match those filters</p>
              <button
                onClick={() => setParams({})}
                className="min-h-[44px] mt-3 text-sm underline px-4"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-5">
              {items.map((p) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
