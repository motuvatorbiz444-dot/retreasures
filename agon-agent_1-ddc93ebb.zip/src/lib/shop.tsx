import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
type CartItem = { product_id: number; title: string; price: number; qty: number; image: string; sku?: string };
const CartCtx = createContext<{ cart: CartItem[]; add: (i: CartItem) => void; updateQty: (id: number, qty: number) => void; remove: (id: number) => void; clear: () => void; count: number; subtotal: number }>({ cart: [], add: () => {}, updateQty: () => {}, remove: () => {}, clear: () => {}, count: 0, subtotal: 0 });
export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try { return JSON.parse(localStorage.getItem('rt_cart') || '[]'); } catch { return []; }
  });
  useEffect(() => { localStorage.setItem('rt_cart', JSON.stringify(cart)); }, [cart]);
  const add = (i: CartItem) => setCart(prev => {
    const ex = prev.find(p => p.product_id === i.product_id);
    if (ex) return prev.map(p => (p === ex ? { ...p, qty: p.qty + i.qty } : p));
    return [...prev, i];
  });
  const updateQty = (id: number, qty: number) => setCart(prev => qty <= 0 ? prev.filter(p => p.product_id !== id) : prev.map(p => (p.product_id === id ? { ...p, qty } : p)));
  const remove = (id: number) => setCart(prev => prev.filter(p => p.product_id !== id));
  const clear = () => setCart([]);
  return <CartCtx.Provider value={{ cart, add, updateQty, remove, clear, count: cart.reduce((s, i) => s + i.qty, 0), subtotal: cart.reduce((s, i) => s + i.price * i.qty, 0) }}>{children}</CartCtx.Provider>;
}
export const useCart = () => useContext(CartCtx);
