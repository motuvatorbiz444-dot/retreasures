export const fmt = (n: any) => {
  const v = parseFloat(n || 0);
  return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};
export const condColor = (c: string) => {
  const map: Record<string, string> = {
    'New (Sealed)': 'bg-emerald-100 text-emerald-800',
    'Like New': 'bg-emerald-100 text-emerald-800',
    Excellent: 'bg-teal-100 text-teal-800',
    Good: 'bg-sky-100 text-sky-800',
    Fair: 'bg-amber-100 text-amber-800',
  };
  return map[c] || 'bg-stone-200 text-stone-700';
};
export const CATEGORY_ICONS: Record<string, string> = {
  Electronics: '📺', Furniture: '🛋️', 'Home & Kitchen': '🍳', Tools: '🔧', Collectibles: '🏆',
  'Clothing & Fashion': '👗', Jewelry: '💎', Appliances: '🧊', Automotive: '🚗', 'Sports & Recreation': '⚽',
  'Toys & Games': '🎮', 'Vintage & Antiques': '🏺', Miscellaneous: '📦'
};
export const effPrice = (p: any) => {
  const sale = parseFloat(p?.sale_price);
  const reg = parseFloat(p?.price);
  if (!isNaN(sale) && sale > 0 && !isNaN(reg) && sale < reg) return sale;
  return isNaN(reg) ? 0 : reg;
};
export const isSoldOut = (p: any) => (p?.quantity || 0) <= 0 || p?.status === 'sold';
