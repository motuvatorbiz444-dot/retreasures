export const CONDITION_GRADES = [
  {
    grade: 'New (Sealed)',
    copy: 'unused, in original packaging.',
  },
  {
    grade: 'Like New',
    copy: 'used once or twice, no visible wear.',
  },
  {
    grade: 'Excellent',
    copy: 'light use, minor cosmetic marks, fully functional.',
  },
  {
    grade: 'Good',
    copy: 'normal wear, works perfectly, flaws photographed.',
  },
  {
    grade: 'Fair',
    copy: 'heavy cosmetic wear, works as described, priced accordingly.',
  },
] as const;

export const LOCATION_CITY = 'Naperville';
export const LOCATION_STATE = 'Illinois';
export const LOCATION_FULL = 'Naperville, Illinois';
export const LOCATION_SHORT = 'Naperville, IL';

export const SHIP_LINE =
  'Flat-rate $8.99 shipping, free over $150, or free local pickup.';

export const SHIPPING_COPY =
  'We ship orders to customers beyond our local delivery area. Shipping costs and available options are provided at checkout.';

export const DELIVERY_COPY =
  'Located near Naperville, Illinois? We offer local delivery within approximately 2 hours of Naperville for an additional delivery fee. Delivery pricing varies based on distance and order requirements.';

export const DELIVERY_DETAILS =
  'Choose local delivery at checkout or contact us and we will confirm availability and the exact delivery cost based on distance, order size, and delivery requirements. Local delivery availability may depend on the item, distance, schedule, and other logistical factors.';

export const PICKUP_COPY =
  'Free pickup in Naperville, Illinois. We\u2019ll email the exact address and pickup window after checkout \u2014 pickups Sat\u2013Sun, 10am\u20134pm. Unclaimed orders are re-listed after 7 days. Prefer a meet-up? Message us and we\u2019ll arrange a public location.';

export const CONTACT_EMAIL = '[EMAIL]';
export const CONTACT_PHONE = '[PHONE]';
