import { Refrigerator, Car, Shirt, Gem, Tv, Sofa } from 'lucide-react';

export const CAT_TILES = [
  { name: 'Appliances', Icon: Refrigerator },
  { name: 'Automotive', Icon: Car },
  { name: 'Clothing & Fashion', Icon: Shirt },
  { name: 'Collectibles', Icon: Gem },
  { name: 'Electronics', Icon: Tv },
  { name: 'Furniture', Icon: Sofa },
];

export const CAT_NAMES = CAT_TILES.map((c) => c.name);
