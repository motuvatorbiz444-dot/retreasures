import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import supabase from '../lib/supabase';
type User = { id: string; email: string; name?: string } | null;
const AuthCtx = createContext<{ user: User; loading: boolean; signOut: () => Promise<void>; refresh: () => Promise<void> }>({ user: null, loading: true, signOut: async () => {}, refresh: async () => {} });
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(null);
  const [loading, setLoading] = useState(true);
  const sync = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const u = session?.user;
      if (u) {
        const nm = u.user_metadata?.full_name || u.email?.split('@')[0];
        setUser({ id: u.id, email: u.email || '', name: nm });
        try {
          await fetch('/api/profiles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: u.id, email: u.email, name: nm }) });
        } catch {}
      } else {
        const local = localStorage.getItem('rt_guest');
        if (local) setUser(JSON.parse(local));
        else setUser(null);
      }
    } catch {
      const local = localStorage.getItem('rt_guest');
      setUser(local ? JSON.parse(local) : null);
    }
    setLoading(false);
  };
  useEffect(() => {
    sync();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session?.user) {
        const u = session.user;
        setUser({ id: u.id, email: u.email || '', name: u.user_metadata?.full_name || u.email?.split('@')[0] });
      } else {
        const local = localStorage.getItem('rt_guest');
        setUser(local ? JSON.parse(local) : null);
      }
      setLoading(false);
    });
    return () => subscription.unsubscribe();
  }, []);
  const signOut = async () => { try { await supabase.auth.signOut(); } catch {} localStorage.removeItem('rt_guest'); setUser(null); };
  return <AuthCtx.Provider value={{ user, loading, signOut, refresh: sync }}>{children}</AuthCtx.Provider>;
}
export const useAuth = () => useContext(AuthCtx);
