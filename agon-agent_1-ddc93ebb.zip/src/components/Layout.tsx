import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Gem, Search, ShoppingCart, Menu, X, Bell, LayoutDashboard, Instagram, Facebook } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../lib/shop';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const { count } = useCart();
  const [q, setQ] = useState('');
  const [mobile, setMobile] = useState(false);
  const [notes, setNotes] = useState<any[]>([]);
  const nav = useNavigate();

  useEffect(() => {
    if (!user?.email) {
      setNotes([]);
      return;
    }
    fetch(`/api/notifications?email=${encodeURIComponent(user.email)}`)
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d)) setNotes(d.filter((n: any) => !n.read));
      })
      .catch(() => {});
  }, [user?.email]);

  const go = (e: any) => {
    e.preventDefault();
    nav(q ? `/shop?search=${encodeURIComponent(q)}` : '/shop');
    setMobile(false);
  };

  return (
    <div className="min-h-screen bg-[#faf6ec] text-stone-900">
      <div className="bg-[#111] text-amber-200 text-xs sm:text-sm text-center py-2.5 px-3 tracking-wide min-h-[44px] flex items-center justify-center">
        <p>
          New treasures every week — free shipping over $150, or free pickup in
          Naperville, Illinois.
        </p>
      </div>
      <header className="sticky top-0 z-50 bg-[#111]/95 backdrop-blur border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-3 h-16">
          <Link to="/" className="flex items-center gap-2 shrink-0 min-h-[44px]">
            <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-300 to-amber-600 flex items-center justify-center shadow-lg">
              <Gem className="w-5 h-5 text-black" />
            </span>
            <span className="leading-tight">
              <span className="block font-display text-lg font-bold text-amber-300 tracking-wide">
                ReTreasures
              </span>
              <span className="hidden sm:block text-[10px] uppercase tracking-[0.2em] text-stone-400">
                Hidden Gems · Second Chances
              </span>
            </span>
          </Link>
          <form onSubmit={go} className="hidden md:flex flex-1 max-w-xl mx-auto relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search treasures: chair, drill, mixer..."
              className="w-full min-h-[44px] bg-stone-900 border border-stone-700 rounded-full pl-9 pr-4 py-2 text-sm text-stone-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-400"
            />
          </form>
          <nav className="hidden lg:flex items-center gap-4 xl:gap-5 text-sm text-stone-300 ml-2">
            <Link to="/" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              Home
            </Link>
            <Link to="/shop" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              Shop
            </Link>
            <Link to="/shop?sort=new" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              New Arrivals
            </Link>
            <Link to="/shop?featured=1" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              Featured
            </Link>
            <Link to="/how-it-works" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              How It Works
            </Link>
            <Link to="/shipping" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              Shipping & Delivery
            </Link>
            <Link to="/about" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              About
            </Link>
            <Link to="/contact" className="min-h-[44px] inline-flex items-center hover:text-amber-300">
              Contact
            </Link>
          </nav>
          <div className="flex items-center gap-1 sm:gap-2 ml-auto">
            <Link
              to="/account"
              className="relative min-h-[44px] min-w-[44px] p-2 text-stone-300 hover:text-amber-300 inline-flex items-center justify-center"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {notes.length > 0 && (
                <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                  {notes.length > 9 ? '9+' : notes.length}
                </span>
              )}
            </Link>
            <Link
              to="/cart"
              className="relative min-h-[44px] min-w-[44px] p-2 text-stone-300 hover:text-amber-300 inline-flex items-center justify-center"
              title="Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {count > 0 && (
                <span className="absolute top-1 right-1 bg-amber-400 text-black text-[10px] font-bold min-w-4 h-4 px-1 rounded-full flex items-center justify-center">
                  {count}
                </span>
              )}
            </Link>
            <button
              onClick={() => setMobile(!mobile)}
              className="min-h-[44px] min-w-[44px] p-2 text-stone-300 inline-flex items-center justify-center"
              aria-label="Menu"
            >
              {mobile ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
        {mobile && (
          <div className="lg:hidden border-t border-stone-800 px-4 pb-4 pt-2 space-y-2 bg-[#111]">
            <form onSubmit={go} className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search treasures..."
                className="w-full min-h-[44px] bg-stone-900 border border-stone-700 rounded-full pl-9 pr-4 py-2 text-sm text-stone-100"
              />
            </form>
            {[
              ['/', 'Home'],
              ['/shop', 'Shop All'],
              ['/shop?sort=new', 'New Arrivals'],
              ['/shop?featured=1', 'Featured'],
              ['/how-it-works', 'How It Works'],
              ['/shipping', 'Shipping & Delivery'],
              ['/categories', 'Categories'],
              ['/cart', 'Cart'],
              ['/account', 'My Account'],
              ['/track', 'Order Tracking'],
            ].map(([h, l]) => (
              <Link
                key={h}
                to={h}
                onClick={() => setMobile(false)}
                className="min-h-[44px] flex items-center text-stone-200 py-2 border-b border-stone-800/60"
              >
                {l}
              </Link>
            ))}
          </div>
        )}
      </header>
      <main>{children}</main>
      <footer className="bg-[#111] text-stone-400 mt-16 border-t border-amber-500/20">
        <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-2 md:grid-cols-5 gap-8 text-sm">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-300 to-amber-600 flex items-center justify-center">
                <Gem className="w-4 h-4 text-black" />
              </span>
              <span className="font-display text-lg font-bold text-amber-300">
                ReTreasures
              </span>
            </div>
            <p className="text-stone-500 max-w-xs">
              Hidden Gems. Second Chances. Real Treasures. ReTreasures is a resale
              shop based in Naperville, Illinois — serving local customers around
              Naperville and shipping to customers nationwide.
            </p>
            <p className="text-stone-400 text-xs mt-3">
              [EMAIL] · Naperville, Illinois · We reply within 24 hours
            </p>
            <div className="flex gap-2 mt-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center border border-stone-700 rounded-full hover:border-amber-400 hover:text-amber-300"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center border border-stone-700 rounded-full hover:border-amber-400 hover:text-amber-300"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-amber-200 font-semibold mb-3 text-xs uppercase tracking-widest">
              Shop
            </h4>
            {[
              ['/shop', 'Shop All'],
              ['/shop?sort=new', 'New Arrivals'],
              ['/shop?featured=1', 'Featured'],
              ['/categories', 'Categories'],
              ['/cart', 'Cart'],
              ['/track', 'Order Tracking'],
              ['/shipping', 'Shipping & Delivery'],
              ['/about', 'About ReTreasures'],
              ['/faq', 'FAQ'],
              ['/contact', 'Contact'],
            ].map(([h, l]) => (
              <Link
                key={h + l}
                to={h}
                className="min-h-[44px] flex items-center py-1 hover:text-amber-300"
              >
                {l}
              </Link>
            ))}
          </div>
          <div>
            <h4 className="text-amber-200 font-semibold mb-3 text-xs uppercase tracking-widest">
              Trust & Policies
            </h4>
            {[
              ['/shipping', 'Shipping & Pickup'],
              ['/returns', 'Returns'],
              ['/terms', 'Terms of Service'],
              ['/privacy', 'Privacy Policy'],
            ].map(([h, l]) => (
              <Link
                key={h}
                to={h}
                className="min-h-[44px] flex items-center py-1 hover:text-amber-300"
              >
                {l}
              </Link>
            ))}
          </div>
          <div>
            <h4 className="text-amber-200 font-semibold mb-3 text-xs uppercase tracking-widest">
              Popular Searches
            </h4>
            <p className="text-xs leading-relaxed text-stone-500">
              Resale in Naperville, Illinois · local shopping in Naperville ·
              products available in Naperville · Naperville local delivery ·
              Illinois shipping · local delivery near Naperville · online resale
              store · used items for sale · unique finds · affordable furniture ·
              electronics for sale · collectibles for sale · local resale store ·
              online thrift store · secondhand deals · resale store Naperville ·
              used furniture Naperville · thrift store Naperville · secondhand
              electronics Naperville · online thrift store Chicago western suburbs
            </p>
          </div>
        </div>
        <div className="border-t border-stone-800 py-4 text-center text-xs text-stone-600 px-4">
          © 2026 ReTreasures · Naperville, Illinois · Secure checkout via Stripe
          (cards + digital wallets). We never store raw card data. ·{' '}
          <Link to="/admin" className="underline">
            Admin
          </Link>
        </div>
      </footer>
    </div>
  );
}
