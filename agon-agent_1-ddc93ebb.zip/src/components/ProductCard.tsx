import { Link, useNavigate } from 'react-router-dom';
import { Eye, ShoppingCart } from 'lucide-react';
import { fmt, condColor, effPrice, isSoldOut } from '../lib/utils';
import { useCart } from '../lib/shop';

export default function ProductCard({ p }: { p: any }) {
  const { add } = useCart();
  const nav = useNavigate();
  const img =
    (p.images && p.images[0]) ||
    'https://images.unsplash.com/photo-1519643381401-22c77e60520e?w=600&q=60&auto=format&fit=crop';
  const price = effPrice(p);
  const was = parseFloat(p.price || 0);
  const onSale = p.sale_price != null && parseFloat(p.sale_price) < was;
  const sold = isSoldOut(p);
  const qty = parseInt(p.quantity ?? 1);
  const onlyOne = !sold && qty === 1;
  const quickAdd = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    if (sold) return;
    add({
      product_id: p.id,
      title: p.title,
      price,
      qty: 1,
      image: img,
      sku: p.sku,
    });
    nav('/cart');
  };
  const slug = `${(p.title || 'item')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60)}-${p.id}`;
  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden border border-stone-200/80 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
      <Link to={`/products/${slug}`} className="block">
        <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
          <img
            src={img}
            alt={p.title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-2 left-2 flex gap-1.5">
            {sold ? (
              <span className="bg-stone-900 text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
                SOLD OUT
              </span>
            ) : onSale ? (
              <span className="bg-red-600 text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
                SALE
              </span>
            ) : (
              <span className="bg-emerald-600 text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
                IN STOCK
              </span>
            )}
          </div>
          <span className="absolute bottom-2 right-2 hidden sm:flex items-center gap-1 bg-black/75 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-full opacity-0 group-hover:opacity-100 transition">
            <Eye className="w-3 h-3" />
            Quick View
          </span>
        </div>
      </Link>
      <div className="p-3.5">
        <div className="flex items-center gap-1.5 mb-1.5 min-h-[22px]">
          <Link
            to="/#condition-grades"
            onClick={(e: any) => e.stopPropagation()}
            className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${condColor(
              p.condition
            )}`}
          >
            {p.condition}
          </Link>
          <span className="text-[11px] font-bold text-amber-700 ml-auto">
            {onlyOne ? 'Only 1 left' : ''}
          </span>
        </div>
        <Link to={`/products/${slug}`}>
          <h3 className="font-semibold text-[13px] leading-snug hover:text-amber-700 break-words">
            {p.title}
          </h3>
        </Link>
        <div className="flex items-end justify-between mt-2 gap-2">
          <div>
            {onSale && (
              <div className="text-[11px] text-stone-400 line-through">{fmt(was)}</div>
            )}
            <div
              className={`text-lg font-extrabold ${
                onSale ? 'text-red-700' : 'text-stone-900'
              }`}
            >
              {fmt(price)}
            </div>
          </div>
          <button
            onClick={quickAdd}
            disabled={sold}
            className={`min-h-[44px] text-xs font-bold px-4 rounded-full flex items-center gap-1 ${
              sold
                ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                : 'bg-black text-amber-300 hover:bg-stone-800'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            {sold ? 'Sold' : 'Add'}
          </button>
        </div>
      </div>
    </div>
  );
}
