import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { code } = req.query;
      let q = supabase.from('coupons').select('*').order('created_at', { ascending: false });
      if (code) q = q.eq('code', code.toUpperCase());
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { code, discount_type, discount_value, min_order, active, expires_at } = req.body;
      const { data, error } = await supabase.from('coupons').insert({ code: code.toUpperCase(), discount_type: discount_type || 'percent', discount_value: parseFloat(discount_value), min_order: min_order ? parseFloat(min_order) : 0, active: active !== false, expires_at: expires_at || null }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...rest } = req.body;
      const { data, error } = await supabase.from('coupons').update(rest).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('coupons').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('coupons error:', err); return res.status(500).json({ error: err.message }); }
}
