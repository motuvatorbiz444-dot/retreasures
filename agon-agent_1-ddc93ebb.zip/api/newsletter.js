import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('newsletter').select('*').order('created_at', { ascending: false }).limit(500);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { email } = req.body;
      if (!email || !email.includes('@')) return res.status(400).json({ error: 'Valid email required' });
      const { data, error } = await supabase.from('newsletter').insert({ email }).select().single();
      if (error) {
        if (error.message.includes('duplicate')) return res.status(200).json({ ok: true, duplicate: true });
        throw error;
      }
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('newsletter').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('newsletter error:', err); return res.status(500).json({ error: err.message }); }
}
