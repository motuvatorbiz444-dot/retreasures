import supabase from './db-client.js';
const DEFAULTS = {
  tax_rate: 0.07, shipping_flat: 12.95, free_shipping_over: 150,
  store_name: 'ReTreasures',
  pickup_address: 'ReTreasures Pickup Counter — hours Mon-Sat 10am-6pm',
  returns_policy: '14-day returns on every purchase. Unused with tags; buyer pays return shipping.',
  stripe_publishable_key: '', announcement: "You never know what you'll find at ReTreasures — new treasures daily!"
};
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('settings').select('*');
      if (error) throw error;
      const merged = { ...DEFAULTS };
      (data || []).forEach(r => { merged[r.key] = r.value?.v ?? r.value; });
      return res.status(200).json(merged);
    }
    if (req.method === 'POST') {
      const body = req.body;
      for (const [k, v] of Object.entries(body)) {
        const { data: ex } = await supabase.from('settings').select('*').eq('key', k).limit(1);
        if (ex && ex.length) await supabase.from('settings').update({ value: { v } }).eq('key', k);
        else await supabase.from('settings').insert({ key: k, value: { v } });
      }
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('settings error:', err); return res.status(500).json({ error: err.message }); }
}
