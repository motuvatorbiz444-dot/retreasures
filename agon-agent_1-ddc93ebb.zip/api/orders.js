import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { email, user_id, id } = req.query;
      if (id) {
        const { data, error } = await supabase.from('orders').select('*').eq('id', id).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      let q = supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(200);
      if (email) q = q.eq('customer_email', email);
      if (user_id) q = q.eq('user_id', user_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const b = req.body;
      if (!b.items || !b.items.length) return res.status(400).json({ error: 'Order has no items' });
      const order_number = 'RT-' + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 900 + 100);
      const { data, error } = await supabase.from('orders').insert({
        order_number, customer_name: b.customer_name, customer_email: b.customer_email, user_id: b.user_id || null,
        items: b.items, subtotal: b.subtotal, tax: b.tax || 0, shipping: b.shipping || 0, fees: 0,
        discount: b.discount || 0, total: b.total, status: b.status || 'pending', payment_method: b.payment_method || 'card',
        payment_status: b.payment_status || 'paid', shipping_address: b.shipping_address || {}, coupon_code: b.coupon_code || null
      }).select().single();
      if (error) throw error;
      try {
        for (const it of (b.items || [])) {
          if (!it.product_id || !it.qty) continue;
          const { data: p } = await supabase.from('products').select('quantity').eq('id', it.product_id).single();
          if (!p) continue;
          const left = Math.max(0, (p.quantity || 1) - it.qty);
          await supabase.from('products').update({ quantity: left, status: left <= 0 ? 'sold' : 'active' }).eq('id', it.product_id);
        }
      } catch (e) { console.warn('qty update failed', e.message); }
      await supabase.from('notifications').insert({
        user_email: b.customer_email, user_id: b.user_id || null, type: 'payment',
        title: 'Order confirmed', message: `Order ${order_number} for $${parseFloat(b.total).toFixed(2)} is confirmed. Track it anytime under Order Tracking.`, product_id: null
      });
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...rest } = req.body;
      const { data, error } = await supabase.from('orders').update(rest).eq('id', id).select().single();
      if (error) throw error;
      if (rest.status === 'shipped' || rest.status === 'ready_for_pickup' || rest.status === 'delivered') {
        await supabase.from('notifications').insert({
          user_email: data.customer_email, user_id: data.user_id || null, type: 'shipping',
          title: rest.status === 'shipped' ? 'Your order shipped' : rest.status === 'delivered' ? 'Order delivered' : 'Ready for pickup',
          message: rest.status === 'shipped' ? `Order ${data.order_number} shipped${rest.tracking_number ? ' — tracking ' + rest.tracking_number : ''}.` : rest.status === 'delivered' ? `Order ${data.order_number} was delivered. Enjoy your treasure!` : `Order ${data.order_number} is ready for pickup at ReTreasures.`,
          product_id: null
        });
      }
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('orders error:', err); return res.status(500).json({ error: err.message }); }
}
