import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const [{ data: orders }, { data: products }, { data: profiles }, { data: categories }] = await Promise.all([
      supabase.from('orders').select('*').limit(1000),
      supabase.from('products').select('*').limit(1000),
      supabase.from('profiles').select('*').limit(1000),
      supabase.from('categories').select('*')
    ]);
    const revenue = (orders || []).filter(o => o.payment_status !== 'refunded').reduce((s, o) => s + parseFloat(o.total || 0), 0);
    const itemsSold = (orders || []).reduce((s, o) => s + ((o.items || []).reduce((a, i) => a + (i.qty || 1), 0)), 0);
    const avgOrder = (orders || []).length ? revenue / (orders || []).length : 0;
    const catMap = {};
    (categories || []).forEach(c => { catMap[c.id] = c.name; });
    const catSales = {};
    (orders || []).forEach(o => (o.items || []).forEach(i => {
      const prod = (products || []).find(p => p.id === i.product_id);
      const cn = prod && catMap[prod.category_id] ? catMap[prod.category_id] : (i.category || 'Miscellaneous');
      catSales[cn] = (catSales[cn] || 0) + parseFloat(i.price || 0) * (i.qty || 1);
    }));
    const topCategories = Object.entries(catSales).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, total]) => ({ name, total }));
    const last14 = [];
    for (let d = 13; d >= 0; d--) {
      const day = new Date(Date.now() - d * 86400000).toISOString().slice(0, 10);
      const dayTotal = (orders || []).filter(o => (o.created_at || '').slice(0, 10) === day).reduce((s, o) => s + parseFloat(o.total || 0), 0);
      last14.push({ day: day.slice(5), total: Math.round(dayTotal * 100) / 100 });
    }
    const r2 = n => Math.round(n * 100) / 100;
    return res.status(200).json({
      revenue: r2(revenue), orders: (orders || []).length, itemsSold,
      customers: (profiles || []).length, avgOrder: r2(avgOrder), topCategories, last14,
      inventory: (products || []).length, lowStock: (products || []).filter(p => (p.quantity || 0) <= 2 && p.status === 'active').length
    });
  } catch (err) { console.error('analytics error:', err); return res.status(500).json({ error: err.message }); }
}
