import supabase from './db-client.js';
const extrasOf = (p) => {
  let e = {};
  try { const o = JSON.parse(p.seller_note || ''); if (o && o.__x) e = o; } catch {}
  return {
    sale_price: e.sale_price ?? null,
    sku: e.sku ?? null,
    shipping_available: e.shipping_available !== false,
    pickup_available: e.pickup_available !== false,
  };
};
const withExtras = (p) => (p ? { ...p, ...extrasOf(p) } : p);
const packExtras = (b) => JSON.stringify({ __x: 1, sale_price: b.sale_price != null && b.sale_price !== '' ? parseFloat(b.sale_price) : null, sku: b.sku || null, shipping_available: b.shipping_available !== false, pickup_available: b.pickup_available !== false });
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { id, category_id, status, featured, search, limit, sort, avail } = req.query;
      if (id) {
        const { data, error } = await supabase.from('products').select('*').eq('id', id).single();
        if (error) throw error;
        await supabase.from('products').update({ views: (data.views || 0) + 1 }).eq('id', id);
        return res.status(200).json(withExtras(data));
      }
      let q = supabase.from('products').select('*').order(sort === 'price_asc' ? 'price' : sort === 'price_desc' ? 'price' : 'created_at', { ascending: sort === 'price_asc' ? true : sort === 'price_desc' ? false : false });
      if (category_id) q = q.eq('category_id', category_id);
      if (status) q = q.eq('status', status);
      if (featured === 'true') q = q.eq('featured', true);
      if (search) q = q.ilike('title', `%${search}%`);
      if (limit) q = q.limit(parseInt(limit));
      else q = q.limit(200);
      const { data, error } = await q;
      if (error) throw error;
      let rows = (data || []).map(withExtras);
      if (avail === 'in') rows = rows.filter(p => (p.quantity || 0) > 0 && p.status !== 'sold');
      if (sort === 'deals') rows = rows.filter(p => p.sale_price != null && parseFloat(p.sale_price) < parseFloat(p.price));
      return res.status(200).json(rows);
    }
    if (req.method === 'POST') {
      const b = req.body;
      if (!b.title) return res.status(400).json({ error: 'Item name is required' });
      if (b.price == null || b.price === '' || isNaN(parseFloat(b.price))) return res.status(400).json({ error: 'Price is required' });
      const row = {
        title: b.title, description: b.description || '', brand: b.brand || null, model: b.model || null,
        category_id: b.category_id ? parseInt(b.category_id) : null, condition: b.condition || 'Good',
        price: parseFloat(b.price),
        quantity: b.quantity != null ? parseInt(b.quantity) : 1,
        images: b.images || [], dimensions: b.dimensions || null,
        shipping_info: b.shipping_info || null, pickup_info: b.pickup_info || null,
        return_info: b.return_info || '14-day returns on every purchase. Unused with tags; buyer pays return shipping.',
        status: b.status || 'active', featured: !!b.featured,
        seller_note: packExtras(b)
      };
      const { data, error } = await supabase.from('products').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(withExtras(data));
    }
    if (req.method === 'PUT') {
      const { id, ...rest } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const clean = {};
      for (const [k, v] of Object.entries(rest)) if (v !== undefined) clean[k] = v;
      if (clean.quantity != null) clean.quantity = parseInt(clean.quantity);
      if (clean.price != null && clean.price !== '') clean.price = parseFloat(clean.price);
      if (clean.category_id === '') clean.category_id = null;
      const packKeys = ['sale_price', 'sku', 'shipping_available', 'pickup_available'];
      const wantsPack = packKeys.some(k => clean[k] !== undefined);
      if (wantsPack) {
        const { data: cur } = await supabase.from('products').select('seller_note').eq('id', id).single();
        let curX = {};
        try { const o = JSON.parse(cur?.seller_note || ''); if (o && o.__x) curX = o; } catch {}
        const merged = {
          __x: 1,
          sale_price: clean.sale_price !== undefined ? (clean.sale_price === '' || clean.sale_price == null ? null : parseFloat(clean.sale_price)) : (curX.sale_price ?? null),
          sku: clean.sku !== undefined ? (clean.sku || null) : (curX.sku ?? null),
          shipping_available: clean.shipping_available !== undefined ? !!clean.shipping_available : (curX.shipping_available !== false),
          pickup_available: clean.pickup_available !== undefined ? !!clean.pickup_available : (curX.pickup_available !== false),
        };
        clean.seller_note = JSON.stringify(merged);
      }
      for (const k of packKeys) delete clean[k];
      const { data, error } = await supabase.from('products').update(clean).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(withExtras(data));
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('products error:', err); return res.status(500).json({ error: err.message }); }
}
