import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { email, user_id } = req.query;
      let q = supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(100);
      if (email) q = q.eq('user_email', email);
      if (user_id) q = q.eq('user_id', user_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { data, error } = await supabase.from('notifications').insert(req.body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, read, readAll, user_email } = req.body;
      if (readAll && user_email) {
        const { error } = await supabase.from('notifications').update({ read: true }).eq('user_email', user_email);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      const { data, error } = await supabase.from('notifications').update({ read: read !== false }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('notifications').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('notifications error:', err); return res.status(500).json({ error: err.message }); }
}
