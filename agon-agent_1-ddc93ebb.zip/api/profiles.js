import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { email, user_id } = req.query;
      let q = supabase.from('profiles').select('*').limit(500);
      if (email) q = q.eq('email', email);
      if (user_id) q = q.eq('user_id', user_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { user_id, email, name, phone, addresses, payment_hint, settings } = req.body;
      const { data: existing } = await supabase.from('profiles').select('*').eq('email', email).limit(1);
      if (existing && existing.length) {
        const { data, error } = await supabase.from('profiles').update({ user_id: user_id || existing[0].user_id, name: name ?? existing[0].name, phone: phone ?? existing[0].phone, addresses: addresses ?? existing[0].addresses, payment_hint: payment_hint ?? existing[0].payment_hint, settings: settings ?? existing[0].settings }).eq('id', existing[0].id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('profiles').insert({ user_id, email, name, phone, addresses: addresses || [], payment_hint, settings: settings || {} }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...rest } = req.body;
      const { data, error } = await supabase.from('profiles').update(rest).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('profiles error:', err); return res.status(500).json({ error: err.message }); }
}
