import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { product_id } = req.query;
      let q = supabase.from('reviews').select('*').order('created_at', { ascending: false }).limit(200);
      if (product_id) q = q.eq('product_id', product_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { product_id, author_name, rating, title, body } = req.body;
      const { data, error } = await supabase.from('reviews').insert({ product_id: product_id ? parseInt(product_id) : null, author_name, rating: parseInt(rating), title, body }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('reviews').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('reviews error:', err); return res.status(500).json({ error: err.message }); }
}
