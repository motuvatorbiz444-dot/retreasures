import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const { items, coupon_code, fulfillment } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'Cart is empty' });
    const { data: settingsRows } = await supabase.from('settings').select('*');
    const s = {};
    (settingsRows || []).forEach(r => { s[r.key] = r.value?.v ?? r.value; });
    const taxRate = parseFloat(s.tax_rate ?? 0.07);
    const shipFlat = parseFloat(s.shipping_flat ?? 8.99);
    const freeOver = parseFloat(s.free_shipping_over ?? 150);
    let subtotal = 0;
    const detailed = [];
    for (const it of items) {
      const { data: p } = await supabase.from('products').select('*').eq('id', it.product_id).single();
      if (!p) continue;
      if ((p.quantity || 0) <= 0 || p.status === 'sold') return res.status(400).json({ error: `"${p.title}" just sold out.` });
      if ((it.qty || 1) > (p.quantity || 1)) return res.status(400).json({ error: `Only ${p.quantity} of "${p.title}" available.` });
      let sale = NaN, sku = null;
      try { const o = JSON.parse(p.seller_note || ''); if (o && o.__x) { sale = parseFloat(o.sale_price); sku = o.sku || null; } } catch {}
      const reg = parseFloat(p.price || 0);
      const price = (!isNaN(sale) && sale > 0 && sale < reg) ? sale : reg;
      subtotal += price * (it.qty || 1);
      detailed.push({ product_id: p.id, title: p.title, price, qty: it.qty || 1, image: (p.images || [])[0] || '', sku });
    }
    let discount = 0;
    if (coupon_code) {
      const { data: coupons } = await supabase.from('coupons').select('*').eq('code', coupon_code.toUpperCase()).eq('active', true).limit(1);
      const c = coupons && coupons[0];
      if (c && subtotal >= parseFloat(c.min_order || 0) && (!c.expires_at || new Date(c.expires_at) > new Date())) {
        discount = c.discount_type === 'percent' ? subtotal * parseFloat(c.discount_value) / 100 : parseFloat(c.discount_value);
        discount = Math.min(discount, subtotal);
      }
    }
    const afterDiscount = subtotal - discount;
    const tax = afterDiscount * taxRate;
    // pickup: always free. delivery: flat handling shown now, exact distance-based
    // fee confirmed with the customer before dispatch. ship: flat rate / free over threshold.
    const shipping = fulfillment === 'pickup' ? 0 : (afterDiscount >= freeOver || afterDiscount === 0 ? 0 : shipFlat);
    const delivery_pending = fulfillment === 'delivery';
    const total = afterDiscount + tax + shipping;
    const r2 = n => Math.round(n * 100) / 100;
    return res.status(200).json({
      items: detailed, subtotal: r2(subtotal), discount: r2(discount), fees: 0,
      tax: r2(tax), tax_rate: taxRate, shipping: r2(shipping), delivery_pending, total: r2(total),
      shipping_note: fulfillment === 'delivery' ? 'Local delivery fee varies by distance and order size — exact cost confirmed before dispatch.' : fulfillment === 'pickup' ? 'Free local pickup in Naperville, Illinois.' : null,
      processor: 'stripe', publishable_key_present: !!(s.stripe_publishable_key)
    });
  } catch (err) { console.error('checkout error:', err); return res.status(500).json({ error: err.message }); }
}
